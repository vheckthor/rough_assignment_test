from typing import Dict, Any, Tuple, List
import time
import numpy as np
import pandas as pd
import bnlearn as bn
from sklearn.preprocessing import KBinsDiscretizer

from bayesian_net.src.structure_learning.structure_algorithm import learn_structure_hillclimb, learn_structure_pc_stable, learn_structure_hybrid_mm_hillclimb_with_score
from bayesian_net.src.parameter_learning.cpt_generator import estimate_cpts, BNModel, calculate_loglikelihood
from bayesian_net.src.evaluator import evaluate_model
from bayesian_net.src.utils.structure_enum import CI_TestEnum, ScoreEnum, StructureTypeEnum


class BNPipeline:
    def __init__(self, n_splits: int = 5, seed: int = 42, bins: int = 5, max_bnlearn_rows: int = 20_000):
        self.n_splits = n_splits
        self.seed = seed
        self.bins = bins
        self.max_bnlearn_rows = max_bnlearn_rows

    def detect_continuous_columns(self, df: pd.DataFrame, exclude: List[str]) -> List[str]:
        feature_cols = [c for c in df.columns if c not in exclude]
        numeric_cols = df[feature_cols].select_dtypes(include=[np.number]).columns.tolist()
        return [c for c in numeric_cols if df[c].nunique(dropna=True) > 2]

    def bootstrap_qcut_discretize(self, df_train: pd.DataFrame, df_test: pd.DataFrame, target_col: str) -> Tuple[pd.DataFrame, pd.DataFrame]:
        feature_cols: List[str] = [c for c in df_train.columns if c != target_col]
        continuous_cols = self.detect_continuous_columns(df_train, exclude=[target_col])
        df_train_out = df_train.copy()
        df_test_out = df_test.copy()
        
        # Define label mapping for interpretability (optional)
        label_mapping = {0: 'low', 1: 'medium', 2: 'high', 3: 'very_high', 4: 'extreme'}
        
        for col in continuous_cols:
            try:
                codes, bins = pd.qcut(df_train_out[col], q=self.bins, labels=False, duplicates='drop', retbins=True)
                
                df_train_out[col] = codes.astype('Int64').astype(str)
                df_test_out[col] = pd.cut(df_test_out[col], bins=bins, include_lowest=True, labels=False).astype('Int64').astype(str)
                
                # Option B: If you absolutely need string labels, use vectorized mapping (slower but more efficient than pd.qcut with labels)
                df_train_out[col] = codes.map(label_mapping).astype(str)
                df_test_out[col] = pd.cut(df_test_out[col], bins=bins, include_lowest=True, labels=False).map(label_mapping).astype(str)
                
            except Exception:
                df_train_out[col] = df_train_out[col].astype(str)
                df_test_out[col] = df_test_out[col].astype(str)
        # cast remaining to string
        for col in feature_cols:
            if col not in continuous_cols:
                df_train_out[col] = df_train_out[col].astype(str)
                df_test_out[col] = df_test_out[col].astype(str)
        df_train_out[target_col] = df_train_out[target_col].astype(str)
        df_test_out[target_col] = df_test_out[target_col].astype(str)
        return df_train_out, df_test_out



    # Convert categorical columns to numeric
    def categoricals_to_numeric(self, df: pd.DataFrame, columns: List[str] = None) -> Tuple[pd.DataFrame, Dict[str, Dict[str, int]]]:
        """
        Convert categorical columns to numeric labels.
        
        Parameters:
        - df: DataFrame
        - columns: List of columns to convert (if None, converts all object/categorical columns)
        
        Returns:
        - DataFrame with numeric labels
        - Dictionary of mappings {column: {label: numeric_value}}
        """
        df_numeric = df.copy()
        mappings = {}
        
        # If no columns specified, find all categorical columns
        if columns is None:
            columns = df.select_dtypes(include=['object', 'category']).columns.tolist()
        
        for col in columns:
            # Convert to categorical and get numeric codes
            cat_data = pd.Categorical(df[col])
            df_numeric[col] = cat_data.codes
            
            # Store mapping
            mappings[col] = dict(zip(cat_data.categories, range(len(cat_data.categories))))
        
        return df_numeric, mappings

    def bnlearn_discretize(self, df: pd.DataFrame, target_col: str) -> Tuple[pd.DataFrame, Dict[str, Dict[str, int]]]:
        continuous_cols = self.detect_continuous_columns(df, exclude=[target_col])
        edges = [(target_col, col) for col in list(df.columns) if col != target_col]

        print(f"============== Discretizing data with edges: {edges} ==============")
        df_disc = bn.discretize(data=df, edges=edges, continuous_columns=continuous_cols, max_iterations=1, verbose=0)
        _ , mappings = self.categoricals_to_numeric(df_disc)
        if isinstance(mappings, dict):
            mappings['strategy'] = 'bnlearn'
            mappings['continuous_cols'] = continuous_cols
        return df_disc, mappings

    def quantile_discretize_dataset(self, df: pd.DataFrame, target_col: str) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        df_out = df.copy()
        continuous_cols = self.detect_continuous_columns(df_out, exclude=[target_col])
        cutpoints: Dict[str, List[float]] = {}

        for col in continuous_cols:
            try:
                codes, bins = pd.qcut(df_out[col], q=self.bins, labels=False, duplicates='drop', retbins=True)
                df_out[col] = codes.astype('Int64').astype(str)
                cutpoints[col] = bins.tolist()
            except Exception:
                df_out[col] = df_out[col].astype(str)

        for col in df_out.columns:
            if col == target_col:
                continue
            if col not in continuous_cols:
                df_out[col] = df_out[col].astype(str)

        df_out[target_col] = df_out[target_col].astype(str)
        mappings = {
            'strategy': 'quantile',
            'continuous_cols': continuous_cols,
            'cutpoints': cutpoints,
            'bins': self.bins,
        }
        return df_out, mappings

    def sk_discretizer(self, df: pd.DataFrame, target_col: str) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    # Discretize dataset using sklearn
        kbins = KBinsDiscretizer(n_bins=self.bins, encode='ordinal', strategy='quantile')
        return kbins
    
    def sk_learn_transform(self, df: pd.DataFrame, continuous_cols: List[str], target_col: str, discretizer: KBinsDiscretizer) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        transformed_values = discretizer.transform(df[continuous_cols])

        df_out = df.copy()
        discretized_df = pd.DataFrame(transformed_values, columns=continuous_cols, index=df_out.index)

        for col in continuous_cols:
            df_out[col] = discretized_df[col].astype(int).astype(str)

        for col in df_out.columns:
            if col not in continuous_cols:
                df_out[col] = df_out[col].astype(str)

        # df_out[target_col] = df_out[target_col].astype(str)
        return df_out

    def sklearn_discretize(self, df: pd.DataFrame, target_col: str, discretizer: KBinsDiscretizer) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        continuous_cols = self.detect_continuous_columns(df, exclude=[target_col])
        df_out = df.copy()

        if not continuous_cols:
            df_out = df_out.astype(str)
            mappings = {
                'strategy': 'sklearn',
                'continuous_cols': continuous_cols,
                'cutpoints': {},
                'bins': self.bins,
            }
            return df_out, mappings

        discretized_values = discretizer.fit_transform(df_out[continuous_cols])
        discretized_df = pd.DataFrame(discretized_values, columns=continuous_cols, index=df_out.index)

        for col in continuous_cols:
            df_out[col] = discretized_df[col].astype(int).astype(str)

        for col in df_out.columns:
            if col not in continuous_cols:
                df_out[col] = df_out[col].astype(str)

        df_out[target_col] = df_out[target_col].astype(str)

        cutpoints = {col: edges.tolist() for col, edges in zip(continuous_cols, discretizer.bin_edges_)}
        mappings = {
            'strategy': 'sklearn',
            'continuous_cols': continuous_cols,
            'cutpoints': cutpoints,
            'bins': self.bins,
        }
        return df_out, mappings

    def discretize_dataset(self, df: pd.DataFrame, target_col: str, strategy: str = 'bnlearn') -> Tuple[pd.DataFrame, Dict[str, Any]]:
        strategy = (strategy or 'bnlearn').lower()
        if strategy == 'bnlearn':
            if len(df) > self.max_bnlearn_rows:
                print(
                    f"Dataset has {len(df)} rows, exceeding max_bnlearn_rows={self.max_bnlearn_rows}. "
                    "Falling back to quantile discretization."
                )
                return self.quantile_discretize_dataset(df, target_col)
            return self.bnlearn_discretize(df, target_col)
        if strategy == 'quantile':
            return self.quantile_discretize_dataset(df, target_col)
        if strategy == 'sklearn':
            return self.sklearn_discretize(df, target_col)
        raise ValueError(f"Unknown discretization strategy: {strategy}")

    def bnlearn_discretize_with_edges(self, df_train: pd.DataFrame, df_test: pd.DataFrame, target_col: str, edges: List[Tuple[str, str]]) -> Tuple[pd.DataFrame, pd.DataFrame]:
        import bnlearn as bn
        # Ensure target exists consistently
        if target_col not in df_train.columns or target_col not in df_test.columns:
            fallback = df_train.columns[-1]
            if fallback in df_test.columns:
                target_col = fallback
            else:
                common = [c for c in df_train.columns if c in df_test.columns]
                target_col = common[-1]
        continuous_cols = self.detect_continuous_columns(df_train, exclude=[target_col])
        # Combine to ensure consistent discretization, then split back (safe drop)
        combined = pd.concat([
            df_train.drop(columns=[target_col], errors='ignore'),
            df_test.drop(columns=[target_col], errors='ignore')
        ], axis=0, ignore_index=True)
        combined_disc = bn.discretize(data=combined, edges=edges, continuous_columns=continuous_cols, max_iterations=8, verbose=0)
        # Reattach targets
        train_len = len(df_train)
        Xtr_disc = combined_disc.iloc[:train_len, :].astype(str)
        Xte_disc = combined_disc.iloc[train_len:, :].astype(str)
        # Ensure target is present before concatenation
        if target_col not in df_train.columns:
            raise ValueError(f"Target column '{target_col}' missing from training dataframe during discretization")
        if target_col not in df_test.columns:
            raise ValueError(f"Target column '{target_col}' missing from test dataframe during discretization")
        df_train_out = pd.concat([Xtr_disc, df_train[[target_col]].astype(str)], axis=1)
        df_test_out = pd.concat([Xte_disc, df_test[[target_col]].astype(str)], axis=1)
        return df_train_out, df_test_out

    def learn_structure(self, df_train_discrete: pd.DataFrame, method: StructureTypeEnum, save_png: str | None = None, max_iter: int = 20_000_000, score_type: ScoreEnum = ScoreEnum.AIC, ci_test: CI_TestEnum = CI_TestEnum.CHI_SQUARE) -> Dict[str, Any]:
        match method:
            case StructureTypeEnum.HILLCLIMB:
                result = learn_structure_hillclimb(df_train_discrete, max_iter=max_iter, save_png=save_png, score_type=score_type)
            case StructureTypeEnum.PC_STABLE:
                result = learn_structure_pc_stable(df_train_discrete, ci_test=ci_test.value, save_png=save_png)
            case StructureTypeEnum.HYBRID_MM_HILLCLIMB_WITH_SCORE:
                result = learn_structure_hybrid_mm_hillclimb_with_score(df_train_discrete, 
                max_iter=max_iter, 
                save_png=save_png, 
                score_type=score_type.value, 
                ci_test=ci_test.value)
            case _:
                raise ValueError(f"Unknown structure learning method: {method}")
        return result

    def learn_parameters(self, df_train_discrete: pd.DataFrame, edges: List[tuple]) -> BNModel:
        start = time.perf_counter()
        model = estimate_cpts(df_train_discrete, edges, laplace=1.0)
        elapsed = time.perf_counter() - start
        return model, elapsed

    def evaluate(self, model: BNModel, df_test_discrete: pd.DataFrame, target_col: str) -> Tuple[Dict[str, float], float]:
        test_rows = df_test_discrete.astype(str).to_dict(orient='records')
        metrics, infer_time = evaluate_model(model, test_rows, target_col)
        return metrics, infer_time

    def log_likelyhood_estimation(self, model: BNModel, df_test_discrete: pd.DataFrame) -> float:
        log_likelyhood, infer_time = calculate_loglikelihood(model, df_test_discrete)
        return {'log_likelyhood': log_likelyhood}, infer_time