import os
import time
from typing import Any, Dict
import pandas as pd
from bayesian_net.src.pipeline import BNPipeline
from bayesian_net.src.utils.pickle_handler import save_pickle
from bayesian_net.src.utils.structure_enum import CI_TestEnum, ScoreEnum, StructureTypeEnum


def best_computation_results(train: pd.DataFrame, test: pd.DataFrame, 
    target_col: str, discretizer: str = 'sklearn', 
    bins: int = 5, method: StructureTypeEnum = StructureTypeEnum.HILLCLIMB, 
    max_iter: int = 20_000_000, max_bnlearn_rows: int = 20_000, png_path: str = None, 
    result_paths: Dict[str, Any] = None, 
    score_type: ScoreEnum = ScoreEnum.AIC, 
    ci_test: CI_TestEnum = CI_TestEnum.CHI_SQUARE, 
    csv_path: str = None) -> Dict[str, Any]:

    if method == StructureTypeEnum.HILLCLIMB:
        return best_computation_hillclimb(
            train, 
            test, 
            target_col, 
            discretizer, 
            bins, 
            method, 
            max_iter, 
            max_bnlearn_rows, 
            png_path, 
            result_paths, 
            score_type, 
            csv_path)
    elif method == StructureTypeEnum.HYBRID_MM_HILLCLIMB_WITH_SCORE:
        return best_computation_hybrid_mm_hillclimb_with_score(
            train, 
            test, 
            target_col, 
            discretizer, 
            bins, 
            score_type, 
            method, 
            ci_test,
            max_iter,
            max_bnlearn_rows,
            png_path,
            result_paths,
            csv_path)
    elif method == StructureTypeEnum.PC_STABLE:
        return best_computation_pc_stable(
            train, 
            test, 
            target_col, 
            discretizer, 
            bins, 
            method, 
            ci_test,
            max_iter, max_bnlearn_rows, png_path, result_paths, csv_path)
    else:
        raise ValueError(f"Invalid method: {method}")
    return None



def best_computation_hillclimb(train: pd.DataFrame, test: pd.DataFrame, target_col: str, discretizer: str = 'sklearn', bins: int = 5,
 method: StructureTypeEnum = StructureTypeEnum.HILLCLIMB, max_iter: int = 20_000_000, max_bnlearn_rows: int = 20_000, 
 png_path: str = None, result_paths: Dict[str, Any] = None, score_type: ScoreEnum = ScoreEnum.AIC,
 csv_path: str = None) -> None:
    
    start = time.perf_counter()
    pipeline = BNPipeline(n_splits=5, seed=42, bins=5, max_bnlearn_rows=max_bnlearn_rows or len(train))
    discretizer_obj = None
    df_train = None
    mappings = None
    if discretizer == 'sklearn':
        discretizer_obj = pipeline.sk_discretizer(train, target_col)
        df_train, mappings = pipeline.sklearn_discretize(train, target_col, discretizer_obj)
    else:
        full_data, mappings = pipeline.discretize_dataset(pd.concat(train, test), target_col, strategy=discretizer)

    dataset_name = os.path.basename(csv_path).split('.')[0]
    result_dir = result_paths['cpt_dir'] 
    mappings_dir = os.path.join(
        result_dir,
        'interval_mapping',
        f"{dataset_name}_{score_type.value}_{discretizer}_best.pkl",
    )

    df_fold_train =df_train if discretizer == 'sklearn' else full_data.loc[len(train)].copy()
    df_fold_test = test if discretizer == 'sklearn' else full_data.loc[len(test)].copy()
    # Clean: drop missing rows
    df_train = df_fold_train.dropna()
    df_test_disc = df_fold_test.dropna()

    os.makedirs(os.path.dirname(mappings_dir), exist_ok=True)
            
    save_pickle(mappings, mappings_dir)

    struct = pipeline.learn_structure(df_train, method=method, save_png=png_path, score_type=score_type)
    struct_time = time.perf_counter() - start
    edges = struct.get('edges', [])

    # Parameter learning (CPTs)
    model, param_time = pipeline.learn_parameters(df_train, edges)
    total_train_time = struct_time + param_time

    # Save CPTs to file
    cpt_path = os.path.join(result_paths['cpt_dir'], f"cpt_{dataset_name}_{method.value}_{score_type.value}_best.txt")
    model.write_config(cpt_path)

    # Evaluate on validation fold (in-fold test)
    if discretizer == 'sklearn':
        df_test_disc = pipeline.sk_learn_transform(test, mappings['continuous_cols'], target_col, discretizer_obj)
    else:
        df_test_disc = df_test_disc
    metrics, infer_time = pipeline.evaluate(model, df_test_disc, target_col)

    row = {
        'dataset': os.path.basename(csv_path),
        'n_train': len(df_train),
        'n_test': len(df_test_disc),
        'discretizer': discretizer,
        'bins': bins,
        'method': method.value,
        'score': score_type.value,
        'max_iter': max_iter,
        'num_edges': len(edges),
        'train_time_s': round(struct_time, 6),
        'param_time_s': round(param_time, 6),
        'total_train_time_s': round(total_train_time, 6),
        'infer_time_s': round(infer_time, 6),
        **metrics,
    }
    return row


def best_computation_pc_stable(train: pd.DataFrame, test: pd.DataFrame, target_col: str, discretizer: str = 'sklearn', bins: int = 5,
 method: StructureTypeEnum = StructureTypeEnum.PC_STABLE, ci_test: CI_TestEnum = CI_TestEnum.CHI_SQUARE, max_iter: int = 20_000_000, max_bnlearn_rows: int = 20_000, 
 png_path: str = None, result_paths: Dict[str, Any] = None, csv_path: str = None) -> None:
    
    start = time.perf_counter()
    pipeline = BNPipeline(n_splits=5, seed=42, bins=5, max_bnlearn_rows=max_bnlearn_rows or len(train))
    discretizer_obj = None
    df_train = None
    mappings = None
    if discretizer == 'sklearn':
        discretizer_obj = pipeline.sk_discretizer(train, target_col)
        df_train, mappings = pipeline.sklearn_discretize(train, target_col, discretizer_obj)
    else:
        full_data, mappings = pipeline.discretize_dataset(pd.concat(train, test), target_col, strategy=discretizer)

    dataset_name = os.path.basename(csv_path).split('.')[0]
    result_dir = result_paths['cpt_dir'] 
    mappings_dir = os.path.join(
        result_dir,
        'interval_mapping',
        f"{dataset_name}_{ci_test.value}_{discretizer}_best.pkl",
    )

    df_fold_train =df_train if discretizer == 'sklearn' else full_data.loc[len(train)].copy()
    df_fold_test = test if discretizer == 'sklearn' else full_data.loc[len(test)].copy()
    # Clean: drop missing rows
    df_train = df_fold_train.dropna()
    df_test_disc = df_fold_test.dropna()

    os.makedirs(os.path.dirname(mappings_dir), exist_ok=True)
            
    save_pickle(mappings, mappings_dir)

    struct = pipeline.learn_structure(df_train, method=method, save_png=png_path, ci_test=ci_test)
    struct_time = time.perf_counter() - start
    edges = struct.get('edges', [])

    # Parameter learning (CPTs)
    print("================= LEARNING PARAMETERS WITH PC STABLE==================")
    model, param_time = pipeline.learn_parameters(df_train, edges)
    total_train_time = struct_time + param_time

    # Save CPTs to file
    cpt_path = os.path.join(result_paths['cpt_dir'], f"cpt_{dataset_name}_{method.value}_{ci_test.value}_best.txt")
    model.write_config(cpt_path)

    # Evaluate on validation fold (in-fold test)
    if discretizer == 'sklearn':
        df_test_disc = pipeline.sk_learn_transform(test, mappings['continuous_cols'], target_col, discretizer_obj)
    else:
        df_test_disc = df_test_disc
    metrics, infer_time = pipeline.evaluate(model, df_test_disc, target_col)
    row = {
        'dataset': os.path.basename(csv_path),
        'n_train': len(df_train),
        'n_test': len(df_test_disc),
        'discretizer': discretizer,
        'bins': bins,
        'method': method.value,
        'score': ci_test.value,
        'max_iter': 0,
        'num_edges': len(edges),
        'train_time_s': round(struct_time, 6),
        'param_time_s': round(param_time, 6),
        'total_train_time_s': round(total_train_time, 6),
        'infer_time_s': round(infer_time, 6),
        **metrics,
    }

    return row


def best_computation_hybrid_mm_hillclimb_with_score(train: pd.DataFrame, test: pd.DataFrame, target_col: str, discretizer: str = 'sklearn', bins: int = 5, score_type:ScoreEnum = ScoreEnum.AIC,
 method: StructureTypeEnum = StructureTypeEnum.HYBRID_MM_HILLCLIMB_WITH_SCORE, ci_test: CI_TestEnum = CI_TestEnum.CHI_SQUARE, max_iter: int = 20_000_000, max_bnlearn_rows: int = 20_000, 
 png_path: str = None, result_paths: Dict[str, Any] = None, csv_path: str = None) -> None:
    
    start = time.perf_counter()
    pipeline = BNPipeline(n_splits=5, seed=42, bins=5, max_bnlearn_rows=max_bnlearn_rows or len(train))
    discretizer_obj = None
    df_train = None
    mappings = None
    if discretizer == 'sklearn':
        discretizer_obj = pipeline.sk_discretizer(train, target_col)
        df_train, mappings = pipeline.sklearn_discretize(train, target_col, discretizer_obj)
    else:
        full_data, mappings = pipeline.discretize_dataset(pd.concat(train, test), target_col, strategy=discretizer)

    dataset_name = os.path.basename(csv_path).split('.')[0]
    result_dir = result_paths['cpt_dir'] 
    mappings_dir = os.path.join(
        result_dir,
        'interval_mapping',
        f"{dataset_name}_{score_type.value}_{ci_test.value}_{discretizer}_best.pkl",
    )

    os.makedirs(os.path.dirname(mappings_dir), exist_ok=True)
            
    save_pickle(mappings, mappings_dir)

    df_fold_train =df_train if discretizer == 'sklearn' else full_data.loc[len(train)].copy()
    df_fold_test = test if discretizer == 'sklearn' else full_data.loc[len(test)].copy()
    # Clean: drop missing rows
    df_train = df_fold_train.dropna()
    df_test_disc = df_fold_test.dropna()


    struct = pipeline.learn_structure(df_train, method=method, save_png=png_path, ci_test=ci_test, score_type=score_type)
    struct_time = time.perf_counter() - start
    edges = struct.get('edges', [])

    # Parameter learning (CPTs)
    model, param_time = pipeline.learn_parameters(df_train, edges)
    total_train_time = struct_time + param_time

    # Save CPTs to file
    cpt_path = os.path.join(result_paths['cpt_dir'], f"cpt_{dataset_name}_{method.value}_{score_type.value}_{ci_test.value}_best.txt")
    model.write_config(cpt_path)

    # Evaluate on validation fold (in-fold test)
    if discretizer == 'sklearn':
        df_test_disc = pipeline.sk_learn_transform(test, mappings['continuous_cols'], target_col, discretizer_obj)
    else:
        df_test_disc = df_test_disc
    metrics, infer_time = pipeline.evaluate(model, df_test_disc, target_col)
    print(f"============== Metrics: {metrics} ==============")
    print(f"============== Infer time: {infer_time} ==============")
    row = {
        'dataset': os.path.basename(csv_path),
        'n_train': len(df_train),
        'n_test': len(df_test_disc),
        'discretizer': discretizer,
        'bins': bins,
        'method': method.value,
        'score': score_type.value,
        'max_iter': max_iter,
        'num_edges': len(edges),
        'train_time_s': round(struct_time, 6),
        'param_time_s': round(param_time, 6),
        'total_train_time_s': round(total_train_time, 6),
        'infer_time_s': round(infer_time, 6),
        **metrics,
    }

    return row