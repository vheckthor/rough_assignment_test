from pgmpy.models import BayesianNetwork
from bayesian_net.src.utils.kfold import create_folds
from bayesian_net.src.pipeline import BNPipeline
from bayesian_net.src.reporting import append_fold_result
from bayesian_net.src.utils.pickle_handler import save_pickle
from bayesian_net.src.utils.structure_enum import CI_TestEnum, ScoreEnum, StructureTypeEnum





from typing import Any, Dict, List
import os
import time
import json



def hybrid_mm_hillclimb_with_score_comparism(
    processed_data: Dict[str, Any],
    csv_path: str,
    n_splits: int = 5,
    seed: int = 42,
    bins: int = 5,
    method: StructureTypeEnum = StructureTypeEnum.HYBRID_MM_HILLCLIMB_WITH_SCORE,
    score_types: List[ScoreEnum] = [ScoreEnum.AIC, ScoreEnum.BIC, ScoreEnum.K2, ScoreEnum.BDEU, ScoreEnum.BDS],
    ci_test: CI_TestEnum = CI_TestEnum.CHI_SQUARE,
    max_iter: int = 1_000_000,
    discretizer: str = 'sklearn',
    max_bnlearn_rows: int = 20_000,
):

    pipeline = BNPipeline(n_splits=n_splits, seed=seed, bins=bins, max_bnlearn_rows=max_bnlearn_rows)

        # Extract processed data and paths
    df_data = processed_data['df_train']
    target_col = processed_data['target_col']
    result_paths = processed_data['result_paths']
    

    folds = create_folds(df_data, target_col=target_col, n_splits=n_splits, seed=seed, stratify=True)
    # Extract result paths for easier access
    per_fold_csv = result_paths['per_fold_csv']
    images_dir = result_paths['images_dir']
    print(f"Running {method} structure learning with {score_types} scores...")
    print(f"Image directory: {images_dir}")
    for score in score_types:
        print(f"Running {method} structure learning...")
        for fold_idx, (train_idx, test_idx) in enumerate(folds):
            train_data = df_data.loc[train_idx].copy()
            test_data = df_data.loc[test_idx].copy()
            discretizer_obj = None
            df_train = None
            mappings = None
            if discretizer == 'sklearn':
                discretizer_obj = pipeline.sk_discretizer(train_data, target_col)
                df_train, mappings = pipeline.sklearn_discretize(train_data, target_col, discretizer_obj)
            else:
                df_train, mappings = pipeline.discretize_dataset(df_data, target_col, strategy=discretizer)

            effective_discretizer = discretizer
            if isinstance(mappings, dict):
                effective_discretizer = mappings.get('strategy', discretizer)
            
            result_dir = result_paths['cpt_dir'] 
            mappings_dir = os.path.join(
                result_dir,
                'interval_mapping',
                f"{os.path.basename(csv_path).split('.')[0]}_{score.value}_{effective_discretizer}_fold{fold_idx+1}.pkl",
            )



            os.makedirs(os.path.dirname(mappings_dir), exist_ok=True)
            
            save_pickle(mappings, mappings_dir)

            df_fold_train =df_train if discretizer == 'sklearn' else df_train.loc[train_idx].copy()
            df_fold_test = test_data if discretizer == 'sklearn' else df_train.loc[test_idx].copy()
            # Clean: drop missing rows
            df_train_disc = df_fold_train.dropna()
            df_test_disc = df_fold_test.dropna()

            # Structure learning on discretized data
            png_path = os.path.join(images_dir, f"dag_{method.value}_{score.value}_fold{fold_idx+1}.png")
            start = time.perf_counter()  
            struct: BayesianNetwork = pipeline.learn_structure(df_train_disc, 
                                    method=method, 
                                    save_png=png_path, 
                                    max_iter=max_iter, 
                                    score_type=score, 
                                    ci_test=ci_test
                                )
            struct_time = time.perf_counter() - start
            edges = struct.edges()
            print("++++===== edges ======++++")
            print(edges)
            print("++++===== cpts ======++++")
            print(struct.get_cpds())

            # Parameter learning (CPTs)
            print(f"learning parameters with edges: {edges}")
            model, param_time = pipeline.learn_parameters(df_train_disc, edges)
            total_train_time = struct_time + param_time

            # Save CPTs to file
            cpt_path = os.path.join(result_paths['cpt_dir'], f"cpt_{method.value}_{score.value}_fold{fold_idx+1}.txt")
            model.write_config(cpt_path)
            
            # Evaluate on validation fold (in-fold test)
            # Evaluate on validation fold (in-fold test)
            if discretizer == 'sklearn':
                df_test_disc = pipeline.sk_learn_transform(test_data, mappings['continuous_cols'], target_col, discretizer_obj)
            else:
                df_test_disc = df_test_disc
            metrics, infer_time = pipeline.evaluate(model, df_test_disc, target_col)
            print(f"============== Metrics: {metrics} ==============")
            print(f"============== Infer time: {infer_time} ==============")

            row = {
                'dataset': os.path.basename(csv_path),
                'fold': fold_idx + 1,
                'n_train': len(df_train_disc),
                'n_test': len(df_test_disc),
                'discretizer': effective_discretizer,
                'bins': bins,
                'method': method.value,
                'score': score.value,
                'max_iter': max_iter,
                'num_edges': len(edges),
                'train_time_s': round(struct_time, 6),
                'param_time_s': round(param_time, 6),
                'total_train_time_s': round(total_train_time, 6),
                'infer_time_s': round(infer_time, 6),
                **metrics,
            }
            append_fold_result(per_fold_csv, row)
 