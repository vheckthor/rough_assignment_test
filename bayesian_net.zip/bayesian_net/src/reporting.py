from typing import Dict, List
import pandas as pd


def append_fold_result(results_csv: str, row: Dict) -> None:
    df = pd.DataFrame([row])
    try:
        from pandas.io.common import file_exists
    except Exception:
        def file_exists(path: str) -> bool:
            try:
                with open(path, 'r'):
                    return True
            except FileNotFoundError:
                return False
    header = not file_exists(results_csv)
    df.to_csv(results_csv, mode='a', header=header, index=False)


def aggregate_results(results_csv: str, summary_csv: str, group_cols: List[str]) -> None:
    df = pd.read_csv(results_csv)
    metrics = [
        'bal_acc', 'f1', 'auc', 'brier', 'kl', 'ecl',
        'train_time_s', 'param_time_s', 'total_train_time_s', 'infer_time_s'
    ]
    
    agg = df.groupby(group_cols)[metrics].agg(['mean', 'std']).reset_index()
    agg.to_csv(summary_csv, index=False)
    return df

def aggregate_log_likelyhood_results(results_csv: str, summary_csv: str, group_cols: List[str]) -> None:
    df = pd.read_csv(results_csv)
    metrics = [
        'log_likelyhood',
        'train_time_s', 'param_time_s', 'total_train_time_s', 'infer_time_s'
    ]
    
    agg = df.groupby(group_cols)[metrics].agg(['mean', 'std']).reset_index()
    agg.to_csv(summary_csv, index=False)
    
    # # Find best performing fold for each group (by balanced accuracy)
    # best_folds = []
    # for group in df.groupby(group_cols):
    #     group_df = group[1]
    #     # Skip groups with no valid bal_acc values
    #     if group_df.empty or group_df['bal_acc'].isna().all():
    #         continue
    #     best_idx = group_df['bal_acc'].idxmax()
    #     best_fold = group_df.loc[best_idx].copy()
    #     best_fold['fold_type'] = 'best'
    #     best_folds.append(best_fold)
    
    # best_df = pd.DataFrame(best_folds)
    
    # # Combine aggregated and best results
    # combined = pd.concat([agg, best_df], ignore_index=True)
    # combined.to_csv(summary_csv, index=False)
