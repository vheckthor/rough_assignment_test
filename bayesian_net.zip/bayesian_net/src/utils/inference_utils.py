#############################################################################
# inference_utils.py
#
# Implements functions to simplify the implementation of algorithms for
# probabilistic inference with Bayesian networks.
#
# influenced by BayesNetUtil.py
#############################################################################

import numpy as np
import networkx as nx



def tokenise_query(prob_query, verbose):
    '''
    query example: P(B|J=true,M=true)
    query dictionary example: query={query_var:'B', evidence:'J=true,M=true'}
    query tokenised dictionary example: query={query_var:'B', evidence:{'J':'true','M':'true'}}
    returns a tokenised dictionary as in the query dictionary example
    '''
    if verbose: print("\nTOKENISING probabilistic query="+str(prob_query))

    query = {}
    prob_query = prob_query[2:]
    prob_query = prob_query[:len(prob_query)-1]
    query["query_var"] = prob_query.split("|")[0]
    query["evidence"] = prob_query.split("|")[1]

    evidence = {}
    if query["evidence"].find(','):
        for pair in query["evidence"].split(','):
            tokens = pair.split('=')
            evidence[tokens[0]] = tokens[1]
        query["evidence"] = evidence

    if verbose: print("query="+str(query))
    return query


def get_parents(child, bn):
    '''
    returns the parent of random variable 'child' given Bayes Net 'bn'
    '''
    for conditional in bn["structure"]:
        if conditional.startswith("P("+child+")"):
            return None
        elif conditional.startswith("P("+child+"|"):
            parents = conditional.split("|")[1]
            parents = parents[:len(parents)-1]
            return parents

    print("ERROR: Couldn't find parent(s) of variable "+str(child))
    exit(0)


def get_probability_given_parents(V, v, evidence, bn):
    '''
    returns the probability of tuple V=v (where V is a random variable and
    v is a domain value) given the evidence and Bayes Net (bn) provided
    '''
    parents = get_parents(V, bn)
    probability = 0

    if parents is None:
        cpt = bn["CPT("+V+")"]
        probability = cpt[v]

    elif parents is not None:
        cpt = bn["CPT("+V+"|"+parents+")"]
        values = v
        for parent in parents.split(","):
            parent = parent.strip()
            
            # Check if parent is in evidence before accessing it
            if parent not in evidence:
                print("ERROR: Parent '%s' of variable '%s' is not in evidence." % (parent, V))
                print("Current evidence keys:", list(evidence.keys()))
                print("Available variables:", bn.get("random_variables", []))
                print("This might indicate variables are not in topological order or enumeration logic issue.")
                raise KeyError("Parent '%s' of variable '%s' not found in evidence. Evidence contains: %s" % 
                             (parent, V, list(evidence.keys())))
            
            separator = "|" if values == v else ","
            values = values + separator + evidence[parent]
        probability = cpt[values]


    else:
        print("ERROR: Don't know how to get probability for V="+str(V))
        exit(0)

    return probability




def get_domain_values(V, bn):
    '''
    returns the domain values of random variable 'V' given Bayes Net 'bn'
    '''
    domain_values = []

    for key, cpt in bn.items():
        if key == "CPT("+V+")":
            domain_values = list(cpt.keys())

        elif key.startswith("CPT("+V+"|"):
            for entry, prob in cpt.items():
                value = entry.split("|")[0]
                if value not in domain_values:
                    domain_values.append(value)

    if len(domain_values) == 0:
        print("ERROR: Couldn't find values of variable "+str(V))
        exit(0)

    return domain_values



def get_number_of_probabilities(V, bn):
    '''
    returns the number of probabilities (full enumeration) of random variable 'V',
    which is currently used to calculate the penalty of the BIC scoring function.
    '''
    for key, cpt in bn.items():
        if key == "CPT("+V+")":
            return len(cpt.keys())

        elif key.startswith("CPT("+V+"|"):
            return len(cpt.items())



def get_index_of_variable(V, bn):
    '''
    returns the index of random variable 'V' given Bayes Net 'bn'
    '''
    for i in range(0, len(bn["random_variables"])):
        variable = bn["random_variables"][i]
        if V == variable:
            return i

    print("ERROR: Couldn't find index of variable "+str(V))
    exit(0)



def normalise(counts):
    '''
    returns a normalised probability distribution of the provided counts,
    where counts is a dictionary of domain_value-counts
    '''
    _sum = 0
    for value, count in counts.items():
        _sum += count

    distribution = {}
    for value, count in counts.items():
        if _sum == 0: p = 0.5 # default if _sum=0
        else: p = float(count/_sum)
        distribution[value] = p

    return distribution

