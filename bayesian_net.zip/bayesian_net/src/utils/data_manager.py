# Reference: aai-workshop-w3
from typing import Optional, Tuple
import os
import pandas as pd
from sklearn.model_selection import train_test_split


class DataManager:
    """
    Handles data loading, splitting, and file management for Bayesian Network experiments.
    """
    
    def __init__(self, seed: int = 42, train_ratio: float = 0.8):
        """
        Initialize the DataManager.
        
        Args:
            seed: Random seed for reproducible splits
            train_ratio: Ratio of data to use for training (rest for testing)
        """
        self.seed = seed
        self.train_ratio = train_ratio
    
    def load_data(self, csv_path: str, target_col: Optional[str] = None, should_split: bool = True) -> Tuple[pd.DataFrame, pd.DataFrame, str]:
        """
        Load data from CSV and split into train/test sets.
        
        Args:
            csv_path: Path to the CSV file
            target_col: Name of the target column (if None, uses last column)
            
        Returns:
            Tuple of (train_df, test_df, target_column_name)
        """
        df: pd.DataFrame = pd.read_csv(csv_path)

        if 'fraud' in os.path.basename(csv_path).lower():
            fraud_drop_cols = ['Transaction_ID', 'Transaaction_ID', 'User_ID', 'Timestamp']
            existing_cols = [col for col in fraud_drop_cols if col in df.columns]
            if existing_cols:
                df = df.drop(columns=existing_cols)
        if target_col is None:
            target_col = df.columns[-1]
        if should_split:
            # Split into train/test
            df_train, df_test = train_test_split(
                df, 
                test_size=1-self.train_ratio, 
                random_state=self.seed, 
                stratify=df[target_col]
            )
            
            return df_train, df_test, target_col
        else:
            return df, None, target_col
    
    def save_splits(self, df_train: pd.DataFrame, df_test: pd.DataFrame, csv_path: str) -> Tuple[str, str]:
        """
        Save train/test splits to files.
        
        Args:
            df_train: Training dataframe
            df_test: Test dataframe
            csv_path: Original CSV path (used to determine output paths)
            
        Returns:
            Tuple of (train_path, test_path)
        """
        # Create processed directory
        processed_dir = os.path.join(os.path.dirname(csv_path), 'processed')
        os.makedirs(processed_dir, exist_ok=True)
        
        # Generate output paths
        base_name = os.path.splitext(os.path.basename(csv_path))[0]
        train_path = os.path.join(processed_dir, f"{base_name}_train.csv")
        test_path = os.path.join(processed_dir, f"{base_name}_test.csv")
        
        # Save splits
        df_train.to_csv(train_path, index=False)
        if df_test is not None:
            df_test.to_csv(test_path, index=False)
        
        print(f"Saved train split ({len(df_train)} rows) to {train_path}")
        print(f"Saved test split ({len(df_test)} rows) to {test_path}")
        
        return train_path, test_path
    
    def setup_results_directories(self, csv_path: str) -> dict:
        """
        Set up directory structure for results and return file paths.
        
        Args:
            csv_path: Original CSV path (used to determine result paths)
            
        Returns:
            Dictionary with result file paths and directories
        """
        # Create results directory
        results_dir = os.path.join(os.path.dirname(csv_path).replace('data',''), 'reports')
        os.makedirs(results_dir, exist_ok=True)
        
        # Create images directory for structure diagrams
        images_dir = os.path.join(results_dir, 'structure_diagrams')
        os.makedirs(images_dir, exist_ok=True)
        
        # Create cpt directory for CPTs
        cpt_dir = os.path.join(os.path.dirname(csv_path).replace('data',''), 'configs')
        os.makedirs(cpt_dir, exist_ok=True)

        
        # Generate result file paths
        base_name = os.path.basename(csv_path)

        paths = {
            'results_dir': results_dir,
            'images_dir': images_dir,
            'cpt_dir': cpt_dir,
            'per_fold_csv': os.path.join(results_dir, f"bn_results_{base_name}"),
            'summary_csv': os.path.join(results_dir, f"bn_summary_{base_name}"),
            'test_csv': os.path.join(results_dir, f"bn_test_{base_name}"),
            'best_results_csv':  os.path.join(results_dir, f"best_results_{base_name}")
        }
        
        return paths
    
    def cleanup_old_results(self, result_paths: dict) -> None:
        """
        Remove old result files to start fresh.
        
        Args:
            result_paths: Dictionary of result file paths
        """
        csv_files = ['per_fold_csv', 'summary_csv', 'test_csv']
        
        for key in csv_files:
            file_path = result_paths.get(key)
            if file_path and os.path.exists(file_path):
                try:
                    os.remove(file_path)
                except Exception as exc:
                    print(f"Error removing file {file_path}: {exc}")
    
    def process_dataset(self, csv_path: str, target_col: Optional[str] = None, should_split: bool = False) -> dict:
        """
        Complete data processing pipeline: load, split, save, and setup results.
        
        Args:
            csv_path: Path to the CSV file
            target_col: Name of the target column (if None, uses last column)
            
        Returns:
            Dictionary containing processed data and file paths
        """
        # Load and split data
        df_train, df_test, target_col = self.load_data(csv_path, target_col, should_split)
        
        if should_split:
        # Save splits
            train_path, test_path = self.save_splits(df_train, df_test, csv_path)
        else:
            train_path = csv_path
            test_path = None
        # Setup results directories
        result_paths = self.setup_results_directories(csv_path)
        
        # Cleanup old results
        self.cleanup_old_results(result_paths)
        
        # Reset index for training data
        if should_split:
            df_train = df_train.reset_index(drop=True)
            df_test = df_test.reset_index(drop=True)
            
        
        return {
            'df_train': df_train,
            'df_test': df_test,
            'target_col': target_col,
            'train_path': train_path,
            'test_path': test_path,
            'result_paths': result_paths
        }
