from enum import Enum

class ComparismTypeEnum(Enum):
    HYBRID_MM_HILLCLIMB_WITH_SCORE = "hybrid_mm_hillclimb_with_score"
    CONSTRAINT_BASED = "constraint_based"
    SCORE_VS_CONSTRAINT_BASED = "score_vs_constraint_based"
    SCORE_VS_SCORE_BASED = "score_vs_score_based"

