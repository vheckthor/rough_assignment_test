from enum import Enum

class StructureTypeEnum(Enum):
    HYBRID_MM_HILLCLIMB_WITH_SCORE = "hybrid_mm_hillclimb_with_score"
    # Score-based
    HILLCLIMB = "hillclimbsearch"
    # Constraint-based
    PC_STABLE = "pc"


class ScoreEnum(Enum):
    AIC = "aic"
    BIC = "bic"
    K2 = "k2"
    BDEU = "bdeu"
    BDS = "bds"


class CI_TestEnum(Enum):
    CHI_SQUARE = "chi_square"
    G_SQUARE = "g_sq"
    LOG_LIKELIHOOD = "log_likelihood"
    INDEPENDENCE_MATCH = 'independence_match'
    PEARSONR = 'pearsonr'
    FREEMAN_TUCKEY = 'freeman_tuckey'
    MOD_LOG_LIKELIHOOD ='modified_log_likelihood'
    NEYMAN = 'neyman'
    CRESSIE_ROAD = 'cressie_read'
    POWER_DIVERGENCE = 'power_divergence'