"""Utility helpers for mapping raw evidence values into discretized bins.

The mapping files are produced during preprocessing and contain pandas
Interval objects that describe each bin. This module exposes convenience
functions to load those mappings and convert raw numeric evidence into the
exact string labels expected by the CPT configuration files.
"""

from __future__ import annotations

from typing import Dict, Iterable, MutableMapping, Any, Tuple

import pandas as pd

from . import pickle_handler


IntervalMapping = Dict[str, Iterable[pd.Interval]]


Metadata = Dict[str, Any]


def _build_intervals_from_cutpoints(
    cutpoints: Dict[str, Iterable[float]],
) -> Dict[str, list[pd.Interval]]:
    intervals: Dict[str, list[pd.Interval]] = {}
    for column, cuts in cutpoints.items():
        cuts_list = list(cuts)
        if len(cuts_list) < 2:
            intervals[column] = []
            continue

        column_intervals: list[pd.Interval] = []
        for idx, (start, end) in enumerate(zip(cuts_list[:-1], cuts_list[1:])):
            if end <= start:
                # Skip degenerate intervals; they provide no range.
                continue
            closed = "both" if idx == 0 else "right"
            column_intervals.append(pd.Interval(left=start, right=end, closed=closed))

        if not column_intervals and cuts_list:
            # Fallback: create a single interval covering min/max to avoid empty features.
            smallest = cuts_list[0]
            largest = cuts_list[-1]
            if largest > smallest:
                column_intervals.append(pd.Interval(left=smallest, right=largest, closed="both"))

        intervals[column] = column_intervals

    return intervals


def _sort_intervals(intervals: Iterable[pd.Interval]) -> list[pd.Interval]:
    return sorted(intervals, key=lambda inter: (inter.left, inter.right))


def load_interval_mapping(path: str) -> Dict[str, Any]:
    """Load a discretization mapping from disk.

    The pickle is expected to contain a ``dict[str, dict[pd.Interval, int]]``
    structure as produced by ``BNPipeline.bnlearn_discretize``. This function
    normalises that structure into a bundle containing:

    - ``metadata`` describing the strategy and any extra parameters
    - ``features`` mapping feature names to interval definitions and
      code lookups
    """

    raw_mapping = pickle_handler.load_pickle(path)
    print("========Raw Mapping:==========", raw_mapping)
    if not isinstance(raw_mapping, dict):
        raise ValueError("Unexpected interval mapping format; expected dictionary.")

    strategy = raw_mapping.get("strategy", "bnlearn")
    metadata: Metadata = {
        "strategy": strategy,
        "bins": raw_mapping.get("bins"),
        "continuous_cols": raw_mapping.get("continuous_cols", []),
    }

    features: Dict[str, Dict[str, Any]] = {}
    metadata_keys = {"strategy", "continuous_cols", "bins"}
    cutpoints: Dict[str, Iterable[float]] = raw_mapping.get("cutpoints", {})
    cutpoint_strategies = {"quantile", "sklearn"}
    cutpoint_intervals = (
        _build_intervals_from_cutpoints(cutpoints)
        if strategy in cutpoint_strategies and cutpoints
        else {}
    )

    raw_feature_entries = {
        feature: interval_info
        for feature, interval_info in raw_mapping.items()
        if feature not in metadata_keys and feature != "cutpoints"
    }

    feature_names = set(raw_feature_entries.keys()) | set(cutpoint_intervals.keys())

    for feature in feature_names:
        intervals: list[pd.Interval] = []
        code_map: Dict[str, str] = {}

        if feature in cutpoint_intervals:
            intervals = list(cutpoint_intervals[feature])
            code_map = {str(interval): str(idx) for idx, interval in enumerate(intervals)}
        else:
            interval_info = raw_feature_entries.get(feature)
            if interval_info is None:
                intervals = []
                code_map = {}
            elif isinstance(interval_info, dict):
                intervals = list(interval_info.keys())
                code_map = {
                    str(interval): str(code)
                    for interval, code in interval_info.items()
                }
            else:
                intervals = list(interval_info)
                code_map = {str(interval): str(interval) for interval in intervals}

        features[feature] = {
            "intervals": intervals,
            "code_map": code_map,
        }

    return {
        "metadata": metadata,
        "features": features,
    }


def discretize_evidence(
    evidence: MutableMapping[str, str], interval_bundle: Dict[str, Any]
) -> None:
    """In-place discretization of evidence values using interval bins.

    For every entry in ``evidence`` that corresponds to a discretized feature,
    this function checks whether the provided value already matches one of the
    discretized labels. If not, it attempts to parse the value as a numeric and
    locate the corresponding interval in the mapping. On success, the evidence
    value is replaced with the code associated with that interval, preserving
    compatibility with both bnlearn-style interval labels and quantile bins.

    Args:
        evidence: Dictionary of evidence variable/value pairs that will be
            updated in-place.
        interval_bundle: Output of :func:`load_interval_mapping` containing
            feature interval definitions and metadata.

    Raises:
        ValueError: If a numeric value cannot be mapped to any interval for the
            corresponding feature.
    """

    if not interval_bundle:
        return

    features = interval_bundle.get("features", {})

    for variable, value in list(evidence.items()):
        if variable not in features:
            continue

        feature_info = features[variable]
        intervals = feature_info.get("intervals", [])
        code_map = feature_info.get("code_map", {})

        # Already in discretized form
        if value in code_map.values():
            continue

        try:
            numeric_value = float(value)
        except (TypeError, ValueError):
            # Non-numeric value that we cannot map; leave untouched.
            continue

        matched_interval = None
        for interval in intervals:
            if numeric_value in interval:
                matched_interval = interval
                break

        if matched_interval is None:
            sorted_intervals = _sort_intervals(intervals)
            if not sorted_intervals:
                raise ValueError(
                    f"No intervals available to discretize variable '{variable}'."
                )
            if numeric_value < sorted_intervals[0].left:
                matched_interval = sorted_intervals[0]
            elif numeric_value > sorted_intervals[-1].right:
                matched_interval = sorted_intervals[-1]
            else:
                raise ValueError(
                    f"Value '{value}' for variable '{variable}' does not fall into any "
                    "known discretization interval."
                )

        interval_key = str(matched_interval)
        if interval_key not in code_map:
            raise KeyError(
                f"No code mapping found for interval '{interval_key}' in feature '{variable}'."
            )

        evidence[variable] = code_map[interval_key]


