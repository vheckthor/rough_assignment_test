#############################################################################
# bayes_net_probabilistic_inference.py
# Implements the algorithm "Inference by Enumeration" and "Rejection Sampling"
# for probabilistic inference with Bayesian networks.
#
# influenced by BayesNetInference.py
#############################################################################

import random
import time
import src.utils.inference_utils as inf_utils
from src.utils.cpt_file_reader import CptFileReader
from src.utils.evidence_mapper import load_interval_mapping, discretize_evidence


class ProbabilisticInference(CptFileReader):
    query = {}
    prob_dist = {}
    verbose = False

    def __init__(
        self,
        alg_name,
        file_name,
        prob_query,
        num_samples=None,
        mapping_path=None,
        verbose=False,
    ):
        super().__init__(file_name)

        self.verbose = verbose
        self.interval_mapping = (
            load_interval_mapping(mapping_path) if mapping_path else None
        )

        if alg_name is None or prob_query is None:
            return

        self.query = inf_utils.tokenise_query(prob_query, self.verbose)
        print("========Query:==========", self.query)
        print("========Interval Mapping:==========", self.interval_mapping)
        if self.interval_mapping:
            if self.verbose:
                print("Original evidence:", self.query["evidence"])
            discretize_evidence(self.query["evidence"], self.interval_mapping)
            if self.verbose:
                print("Discretized evidence:", self.query["evidence"])

        # Pre-compute a topological order so parents appear before children in downstream routines
        self.ordered_random_variables = self.topological_sort(self.bn["random_variables"])

        start = time.time()
        if alg_name == 'InferenceByEnumeration':
            self.prob_dist = self.enumeration_ask()
            normalised_dist = inf_utils.normalise(self.prob_dist)
            print("unnormalised P(%s)=%s" % (self.query["query_var"], self.prob_dist))
            print("normalised P(%s)=%s" % (self.query["query_var"], normalised_dist))

        elif alg_name == 'RejectionSampling':
            self.prob_dist = self.rejection_sampling(num_samples)
            print("P(%s)=%s" %(self.query["query_var"], self.prob_dist))

        else:
            print("ERROR: Couldn't recognise algorithm="+str(alg_name))
            print("Valid choices={InferenceByEnumeration,RejectionSampling}")

        end = time.time()
        print('Execution Time: {}'.format(end-start))

    # reorders variables in topological order (parents before children)
    def topological_sort(self, variables):
        """Returns variables in topological order, ensuring parents come before children"""
        # Build dependency graph: for each variable, find its parents
        dependencies = {}  # variable -> set of parents
        variable_set = set(variables)
        
        for var in variables:
            parents = inf_utils.get_parents(var, self.bn)
            if parents is None:
                dependencies[var] = set()  # no parents
            else:
                # Split and strip parent names
                parent_list = [p.strip() for p in parents.split(",")]
                # Only include parents that are in the variable list
                dependencies[var] = set([p for p in parent_list if p in variable_set])
        
        # Topological sort using Kahn's algorithm
        # Count in-degrees (number of unprocessed parents)
        in_degree = {var: len(dependencies[var]) for var in variables}
        
        # Queue of variables with no unprocessed parents
        queue = [var for var in variables if in_degree[var] == 0]
        result = []
        
        while queue:
            # Process variable with no dependencies
            var = queue.pop(0)
            result.append(var)
            
            # Reduce in-degree for variables that depend on this one
            for other_var in variables:
                if var in dependencies[other_var]:
                    in_degree[other_var] -= 1
                    if in_degree[other_var] == 0:
                        queue.append(other_var)
        
        # If result length != variables length, there's a cycle (shouldn't happen in BN)
        if len(result) != len(variables):
            print("WARNING: Could not complete topological sort. Some variables may be unreachable or there's a cycle.")
            # Return original order if sort fails
            return variables
        
        return result

    # main method for inference by enumeration, which invokes
	# enumerate_all() for each domain value of the query variable
    def enumeration_ask(self):
        if self.verbose: print("\nSTARTING Inference by Enumeration...")


        # initialisation required for discrete Bayes nets
        Q = {}
        for value in self.bn["rv_key_values"][self.query["query_var"]]:
            value = value.split('|')[0]
            Q[value] = 0

        # Get variables in topological order (parents before children)
        variables_ordered = self.topological_sort(self.bn["random_variables"])

        for value, probability in Q.items():

            evidence = self.query["evidence"].copy()
            evidence[self.query["query_var"]] = value
            
            # Enumerate over all variables (in topological order)
            # Hidden variables are summed over, observed variables use their evidence value
            probability = self.enumerate_all(variables_ordered, evidence)
            print("probability:", probability)
            Q[value] = probability

        if self.verbose: print("\tQ="+str(Q))
        return Q # Q is an unnormalised probability distribution

    # returns a probability for the arguments provided, based on
	# summations or multiplications of prior/conditional probabilities
    def enumerate_all(self, variables, evidence):
        if len(variables) == 0:
            return 1.0

        V = variables[0]
        rest_variables = variables.copy()
        rest_variables.pop(0)
        
        # If V is in evidence (observed or query variable), use its value
        if V in evidence:
            v = str(evidence[V]).split('|')[0]
            p = inf_utils.get_probability_given_parents(V, v, evidence, self.bn)
            return p * self.enumerate_all(rest_variables, evidence)
        else:
            # V is hidden, so we need to sum over all its values
            sum = 0
            for v in inf_utils.get_domain_values(V, self.bn):
                evidence[V] = v
                p = inf_utils.get_probability_given_parents(V, v, evidence, self.bn)
                sum += p * self.enumerate_all(rest_variables, evidence)
                # Remove V from evidence after each iteration since it wasn't there originally
                del evidence[V]
            return sum

    # main method to carry out approximate probabilistic inference,
	# which invokes prior_sample() and is_compatible_with_evidence()
    def rejection_sampling(self, num_samples):
        print("\nSTARTING rejection sampling...")
        query_variable = self.query["query_var"]
        evidence = self.query["evidence"]
        samples = [] # vector of non-rejected samples
        C = {} # counts per value in query variable

        # initialise vector of counts
        for value in self.bn["rv_key_values"][query_variable]:
            value = value.split("|")[0]
            C[value] = 0

        # loop to increase counts when the sampled vector X consistent w/evidence
        for i in range(0, num_samples):
            X = self.prior_sample(evidence)
            if X != None and self.is_compatible_with_evidence(X, evidence):
                value_to_increase = X[query_variable]
                C[value_to_increase] += 1

        try:
            print("Countings of query_variable %s=%s" % (query_variable, C))
            return inf_utils.normalise(C)
        except:
            print("ABORTED due to insufficient number of samples...")
            exit(0)

    # returns a dictionary of sampled values for each of the random variables
    def prior_sample(self, evidence):
        X = {}
        sampled_var_values = {}

        # iterates over the set of random variables as specified in the 
		# config file of the Bayes net, in the order from left to right
        for variable in self.ordered_random_variables:
            X[variable] = self.get_sampled_value(variable, sampled_var_values)
            sampled_var_values[variable] = X[variable]
            if variable in evidence and evidence[variable] != X[variable]:
                if self.verbose:
                    print("RETURNING X=", X, " var=", variable, " in e=", evidence)
                return None

        return X

    # returns a sampled value for the given random variable as argument
    def get_sampled_value(self, V, sampled):
        parents = inf_utils.get_parents(V, self.bn)
        cumulative_cpt = {}
        prob_mass = 0

        # generate cummulative distribution for random variable V without parents
        if parents is None:
            for value, probability in self.bn["CPT("+V+")"].items():
                prob_mass += probability
                cumulative_cpt[value] = prob_mass

        # generate cummulative distribution for random variable V with parents
        else:
            for v in inf_utils.get_domain_values(V, self.bn):
                p = inf_utils.get_probability_given_parents(V, v, sampled, self.bn)
                prob_mass += p
                cumulative_cpt[v] = prob_mass

        # check that the probabilities sum to 1 (or almost)
        if prob_mass < 0.999 or prob_mass > 1.001:
            print("ERROR: probabilities=%s do not sum to 1" % (cumulative_cpt))
            exit(0)

		# sample a value from the cummulative distribution generated above
        for value, probability in cumulative_cpt.items():
            random_number = random.random()
            if random_number <= probability:
                return value.split("|")[0]

        return None # this shouldn't happen -- unless something was incompatible

    # returns True if evidence has key-value pairs same as X
	# returns False otherwise
    def is_compatible_with_evidence(self, X, evidence):
        compatible = True
        if self.verbose:
            print("X=", X)
            print("evidence=", evidence)
        for variable, value in evidence.items():
            if self.verbose:
                print("*variable=%s value=%s" % (variable, value))
            if X[variable] != value:
                compatible = False
                break
        return compatible

