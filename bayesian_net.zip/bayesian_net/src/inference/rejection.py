from typing import Dict, List, Optional, Tuple
import random
import warnings

from bayesian_net.src.parameter_learning.cpt_generator import BNModel


def _get_parents(var: str, model: BNModel) -> List[str]:
    return sorted([p for p, c in model.edges if c == var])


def _topological_order(variables: List[str], edges: List[Tuple[str, str]]) -> List[str]:
    adjacency: Dict[str, List[str]] = {v: [] for v in variables}
    for parent, child in edges:
        if parent in adjacency:
            adjacency[parent].append(child)
    visited: Dict[str, int] = {v: 0 for v in variables}
    order: List[str] = []

    def dfs(node: str) -> None:
        state = visited[node]
        if state == 2:
            return
        if state == 1:
            raise ValueError(
                f"Cycle detected in Bayesian Network at node '{node}'. "
                f"Bayesian Networks must be directed acyclic graphs (DAGs)."
            )
        visited[node] = 1
        for nei in adjacency.get(node, []):
            if nei in visited:
                dfs(nei)
        visited[node] = 2
        order.append(node)

    for v in variables:
        if visited[v] == 0:
            dfs(v)
    order.reverse()
    seen = set(order)
    for v in variables:
        if v not in seen:
            order.append(v)
    return order


def _sample_from_probs(
    values: List[str], 
    probs: List[float],
    rng: Optional[random.Random] = None
) -> str:
    """
    Sample a value from a categorical distribution.
    
    Args:
        values: List of possible values
        probs: Probabilities (will be normalized)
        rng: Random number generator for reproducibility
    
    Returns:
        Sampled value
        
    Raises:
        ValueError: If inputs are invalid
    """
    if rng is None:
        rng = random.Random()
    
    # Input validation
    if len(values) == 0:
        raise ValueError("Cannot sample from empty values list")
    
    if len(values) != len(probs):
        raise ValueError(
            f"Length mismatch: {len(values)} values but {len(probs)} probabilities"
        )
    
    # Check for negative probabilities
    if any(p < 0 for p in probs):
        raise ValueError(f"Negative probabilities not allowed: {probs}")
    
    # Check sum
    s = sum(probs)
    if s <= 0:
        raise ValueError(
            f"All-zero or negative probability sum ({s}) for values {values}. "
            f"This indicates a bug in the CPT specification."
        )
    
    # Inverse CDF sampling
    r = rng.random()
    cum = 0.0
    for v, p in zip(values, probs):
        cum += p / s  # Normalize as we accumulate
        if r <= cum:
            return v
    
    # Floating point safety: if we get here due to rounding, return last value
    return values[-1]


def _sample_ancestral(
    model: BNModel, 
    rng: Optional[random.Random] = None
) -> Dict[str, str]:
    """
    Generate a sample from the joint distribution using ancestral sampling.
    
    Args:
        model: Bayesian network model
        rng: Random number generator (for reproducibility)
    
    Returns:
        Complete variable assignment
    """
    if rng is None:
        rng = random.Random()
    
    assignment: Dict[str, str] = {}
    ordered = _topological_order(model.random_variables, model.edges)
    
    for var in ordered:
        parents = _get_parents(var, model)
        domain = model.rv_values[var]
        
        # Ensure all parents already sampled
        if not all(p in assignment for p in parents):
            raise RuntimeError(
                f"Invalid topological order: parent of '{var}' not yet sampled"
            )
        
        # Build CPT lookup key
        if len(parents) == 0:
            key = f"P({var})"
            table = model.cpts.get(key)
            if table is None:
                raise KeyError(f"Missing CPT for root variable '{var}' (key: {key})")
            probs = [float(table.get(val, 0.0)) for val in domain]
        else:
            parent_vals = ",".join([assignment[p] for p in parents])
            key = f"P({var}|{','.join(parents)})"
            table = model.cpts.get(key)
            if table is None:
                raise KeyError(f"Missing CPT for '{var}' given parents {parents} (key: {key})")
            
            probs = [float(table.get(f"{val}|{parent_vals}", 0.0)) for val in domain]
        
        # Validate probability distribution
        prob_sum = sum(probs)
        if prob_sum == 0:
            raise ValueError(
                f"All-zero probabilities for '{var}'. "
                f"CPT entries may be missing or parent values may be invalid."
            )
        
        # Normalize if needed (handle floating point errors)
        if abs(prob_sum - 1.0) > 1e-6:
            probs = [p / prob_sum for p in probs]
        
        chosen = _sample_from_probs(domain, probs, rng)
        assignment[var] = chosen
    
    return assignment


def rejection_sampling_distribution(
    model: BNModel,
    evidence: Dict[str, str],
    query_var: str,
    num_samples: int = 10000,
    seed: int = 42,
    max_attempts: Optional[int] = None
) -> Tuple[Dict[str, float], Dict[str, int], int, int]:
    """Estimate probability distribution for a query variable using rejection sampling.

    Args:
        model: The Bayesian Network model to query
        evidence: Dictionary mapping evidence variables to their observed values
        query_var: The variable to compute the probability distribution for
        num_samples: Number of accepted samples to generate (default: 10000)
        seed: Random seed for reproducibility (default: 42)
        max_attempts: Maximum sampling attempts before giving up (default: num_samples * 100)

    Returns:
        Tuple containing:
        - Dictionary mapping query variable values to their probabilities
        - Dictionary mapping query variable values to their sample counts
        - Number of accepted samples
        - Total number of sampling attempts

    Raises:
        ValueError: If query_var or evidence variables are not in the model
        RuntimeError: If no samples were accepted after max_attempts

    Warns:
        UserWarning: If acceptance rate falls below 1%
    """
    
    # Validation
    if query_var not in model.rv_values:
        raise ValueError(f"Query variable '{query_var}' not in model")
    for var in evidence:
        if var not in model.rv_values:
            raise ValueError(f"Evidence variable '{var}' not in model")
    
    # Local random instance
    rng = random.Random(seed)
    
    counts = {val: 0 for val in model.rv_values[query_var]}
    accepted = 0
    attempted = 0
    max_attempts = max_attempts or num_samples * 100

    while accepted < num_samples and attempted < max_attempts:
        attempted += 1
        sample = _sample_ancestral(model, rng)
        
        # Check evidence consistency
        if all(str(sample.get(var)) == str(val) for var, val in evidence.items()):
            accepted += 1
            counts[sample[query_var]] += 1

    # Warn if acceptance rate is too low
    if accepted < num_samples * 0.1:  # Less than 10% of target
        warnings.warn(
            f"Only {accepted}/{num_samples} samples accepted. "
            f"Acceptance rate: {accepted/attempted:.2%}. Results may be unreliable."
        )
    
    if accepted == 0:
        raise RuntimeError("No samples accepted - evidence may be impossible")
    
    total = sum(counts.values())
    dist = {k: v / total for k, v in counts.items()}
    return dist, counts, accepted, attempted

