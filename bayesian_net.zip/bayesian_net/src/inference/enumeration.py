from typing import Dict, List

from bayesian_net.src.parameter_learning.cpt_generator import BNModel


def _get_parents(var: str, model: BNModel) -> List[str]:
    return sorted([p for p, c in model.edges if c == var])


def _build_topological_order(model: BNModel) -> List[str]:
    """Return variables ordered so parents precede children."""
    # Initialize parent sets for every variable
    parents_map: Dict[str, set] = {v: set() for v in model.random_variables}
    children_map: Dict[str, set] = {v: set() for v in model.random_variables}

    for parent, child in model.edges:
        if child not in parents_map:
            parents_map[child] = set()
        parents_map[child].add(parent)
        children_map.setdefault(parent, set()).add(child)
        children_map.setdefault(child, set())
        parents_map.setdefault(parent, set())

    ready = sorted([v for v, parents in parents_map.items() if len(parents) == 0])
    order: List[str] = []

    while ready:
        node = ready.pop(0)
        order.append(node)
        for child in sorted(children_map.get(node, [])):
            parents = parents_map[child]
            if node in parents:
                parents.remove(node)
                if len(parents) == 0:
                    ready.append(child)
        ready.sort()

    # Append any remaining variables (in original order) in case of cycles/disconnected nodes
    seen = set(order)
    for var in model.random_variables:
        if var not in seen:
            order.append(var)
    return order


def _get_domain_values(var: str, model: BNModel) -> List[str]:
    return model.rv_values[var]


def _prob_given_parents(var: str, value: str, evidence: Dict[str, str], model: BNModel) -> float:
    parents = _get_parents(var, model)
    if len(parents) == 0:
        key = f"P({var})"
        return float(model.cpts[key][value])
    else:
        parent_vals = ",".join([str(evidence[p]) for p in parents])
        key = f"P({var}|{','.join(parents)})"
        return float(model.cpts[key][f"{value}|{parent_vals}"])


def _enumerate_all(variables: List[str], evidence: Dict[str, str], model: BNModel) -> float:
    if len(variables) == 0:
        return 1.0
    v = variables[0]
    rest = variables[1:]
    if v in evidence:
        p = _prob_given_parents(v, str(evidence[v]), evidence, model)
        return p * _enumerate_all(rest, evidence, model)
    else:
        total = 0.0
        for val in _get_domain_values(v, model):
            evidence[v] = val
            p = _prob_given_parents(v, val, evidence, model)
            total += p * _enumerate_all(rest, evidence, model)
            evidence.pop(v, None)
        return total


def predict_distribution(model: BNModel, evidence: Dict[str, str], query_var: str) -> Dict[str, float]:
    Q: Dict[str, float] = {}
    ordered_vars = _build_topological_order(model)
    for val in _get_domain_values(query_var, model):
        ev = dict(evidence)
        ev[query_var] = val
        Q[val] = _enumerate_all(ordered_vars[:], ev, model)
    # normalize
    s = sum(Q.values())
    if s > 0:
        for k in Q:
            Q[k] = Q[k] / s
    return Q
