import bnlearn as bn
import matplotlib
import seaborn as sns
import networkx as nx
import matplotlib.pyplot as plt
from typing import Dict, Any, List, Tuple, Optional

from bayesian_net.src.utils.structure_enum import ScoreEnum

from pgmpy.estimators import PC, HillClimbSearch, K2Score, BDeuScore, BicScore, AICScore
from pgmpy.models import BayesianNetwork

import pandas as pd
sns.set_theme(style="darkgrid")

def _save_structure_png(edges: List[Tuple[str, str]], title: str, file_path: str) -> bool:
    try:
        matplotlib.use('Agg')
        G = nx.DiGraph()
        G.add_edges_from(edges)
        pos = nx.spring_layout(G)
        plt.figure(figsize=(8, 6))
        nx.draw(G, pos, with_labels=True, node_size=1000, node_color='lightblue', font_size=10, arrows=True)
        plt.title(title)
        plt.savefig(file_path, dpi=300, bbox_inches='tight')
        plt.close()
        return True
    except Exception:
        return False


def learn_structure_hillclimb(df, max_iter: int = 1_000_000, save_png: Optional[str] = None, score_type: ScoreEnum = ScoreEnum.AIC) -> Dict[str, Any]:
    """Learn structure using bnlearn hillclimb + AIC. Returns dict with edges and optional model.
    If save_png is provided, attempts to save a DAG image to that path using networkx/matplotlib if available.
    """
    try:
        score_type_value = score_type.value
        model = bn.structure_learning.fit(df, methodtype='hillclimbsearch', scoretype=score_type_value, max_iter=max_iter)
        edges: List[Tuple[str, str]] = list(model.get('model_edges', []))
        print(f"Learnt Structure HC+{score_type_value.upper()}: {edges}")
        if save_png is not None:
            _save_structure_png(edges, f"Learnt Structure HC+{score_type_value.upper()}", save_png)
        return {"edges": edges, "model": model}
    except Exception as e:
        # bnlearn not available or failed; return empty result with error
        print(f"Error learning structure with score: {score_type_value}: {e}")
        return {"edges": [], "model": None, "error": str(e)}


def learn_structure_pc_stable(df, alpha: float = 0.05, ci_test: str = 'chi_square', save_png: Optional[str] = None) -> Dict[str, Any]:
    """Learn structure using bnlearn PC-Stable (constraint-based). Returns dict with edges and optional model.
    If save_png is provided, attempts to save a DAG image to that path using networkx/matplotlib if available.
    """
    try:
        # Pass CI test options through to bnlearn's PC-Stable implementation
        model = bn.structure_learning.fit(
            df,
            methodtype='pc',
            params_pc={'alpha': alpha, 'ci_test': ci_test}
        )
        edges: List[Tuple[str, str]] = list(model.get('dag_edges', []))
        print(f"Learnt Structure PC-Stable: {edges}")
        if save_png is not None:
            _save_structure_png(edges, "Learnt Structure PC-Stable", save_png)
        return {"edges": edges, "model": model}
    except Exception as e:
        # bnlearn not available or failed; return empty result with error
        print(f"An error occured {e}")
        return {"edges": [], "model": None, "error": str(e)}


def learn_structure_hybrid_mm_hillclimb_with_score(df: pd.DataFrame, score_type: str = 'aic', ci_test: str = 'chi_square',
max_iter: int = 1_0000_000, save_png: Optional[str] = None) -> BayesianNetwork:
    """
    Hybrid MM Hillclimb implementation using pgmpy.
    """
    print(f"Running Hybrid MM Hillclimb with Score{score_type}_____________________")
    constraint_learner = PC(df)
    scoring_method = {
        'aic': AICScore(df),
        'bic': BicScore(df),
        'k2': K2Score(df),
        'bdeu': BDeuScore(df),
    }[score_type]
    skeleton_graph, sepset = constraint_learner.build_skeleton(ci_test=ci_test)
    print(f"Sepset: {sepset}")
    print(f"Skeleton: {skeleton_graph}")

    candidate_white_list = set()
    for u, v in skeleton_graph.edges():
        candidate_white_list.add((u, v))
        candidate_white_list.add((v, u))

    candidate_black_list = set()
    for nodes, _ in sepset.items():
        if len(nodes) != 2:
            continue
        node_u, node_v = tuple(nodes)
        candidate_black_list.add((node_u, node_v))
        candidate_black_list.add((node_v, node_u))

    white_list = list(candidate_white_list - candidate_black_list)
    black_list = list(candidate_black_list - candidate_white_list)

    hillclimb = HillClimbSearch(df)
    best_model = hillclimb.estimate(
        scoring_method=scoring_method,
        white_list=white_list if white_list else None,
        black_list=black_list if black_list else None,
        max_iter=max_iter,
    )
    print(f"Best Model: {best_model}")
    model = BayesianNetwork(best_model.edges())
    if save_png is not None:
        _save_structure_png(model.edges(), f"Hybrid MM Hillclimb with Score{score_type}", save_png)
    return model


