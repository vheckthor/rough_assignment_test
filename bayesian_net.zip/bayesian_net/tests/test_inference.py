# tests for custom inference implementations

import pandas as pd
import pytest

from bayesian_net.src.parameter_learning.cpt_generator import estimate_cpts
from bayesian_net.src.inference.enumeration import predict_distribution
from bayesian_net.src.inference.rejection import rejection_sampling_distribution


def _build_simple_model():
    data = [
        {"B": "0", "A": "0"},
        {"B": "0", "A": "0"},
        {"B": "1", "A": "0"},
        {"B": "1", "A": "1"},
        {"B": "1", "A": "1"},
        {"B": "0", "A": "1"},
    ]
    df = pd.DataFrame(data)[["B", "A"]]
    edges = [("A", "B")]
    model = estimate_cpts(df, edges, laplace=0.0)
    return model


def test_enumeration_respects_topological_order():
    model = _build_simple_model()
    dist = predict_distribution(model, {"A": "1"}, "B")

    assert dist.keys() == {"0", "1"}
    assert dist["1"] == pytest.approx(2 / 3, rel=1e-6)
    assert dist["0"] == pytest.approx(1 / 3, rel=1e-6)


def test_enumeration_without_evidence_matches_marginal():
    model = _build_simple_model()
    dist = predict_distribution(model, {}, "B")

    assert dist.keys() == {"0", "1"}
    assert dist["1"] == pytest.approx(0.5, rel=1e-6)
    assert dist["0"] == pytest.approx(0.5, rel=1e-6)


def test_rejection_sampling_aligns_with_enumeration():
    model = _build_simple_model()
    dist, counts, accepted, attempted = rejection_sampling_distribution(
        model,
        {"A": "1"},
        "B",
        num_samples=2000,
        seed=123,
    )

    assert accepted == 2000
    assert sum(counts.values()) == accepted
    assert dist["1"] == pytest.approx(2 / 3, abs=0.05)
    assert dist["0"] == pytest.approx(1 / 3, abs=0.05)

