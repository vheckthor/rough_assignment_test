import pickle

import pandas as pd
import pytest

from bayesian_net.src.utils.evidence_mapper import load_interval_mapping, discretize_evidence


def test_load_interval_mapping_bnlearn(tmp_path):
    path = tmp_path / "bnlearn_mapping.pkl"
    mapping_data = {
        "feature": {
            pd.Interval(0.0, 10.0, closed="right"): 0,
            pd.Interval(10.0, 20.0, closed="right"): 1,
        },
        "continuous_cols": ["feature"],
        "strategy": "bnlearn",
    }
    with open(path, "wb") as fh:
        pickle.dump(mapping_data, fh)

    bundle = load_interval_mapping(str(path))

    assert bundle["metadata"]["strategy"] == "bnlearn"
    assert "feature" in bundle["features"]
    feature_info = bundle["features"]["feature"]
    intervals = feature_info["intervals"]
    assert intervals[0] == pd.Interval(0.0, 10.0, closed="right")
    assert intervals[1] == pd.Interval(10.0, 20.0, closed="right")
    assert feature_info["code_map"][str(intervals[0])] == str(intervals[0])


def test_load_interval_mapping_quantile(tmp_path):
    path = tmp_path / "quantile_mapping.pkl"
    mapping_data = {
        "strategy": "quantile",
        "continuous_cols": ["x"],
        "cutpoints": {"x": [0.0, 5.0, 10.0]},
        "bins": 2,
    }
    with open(path, "wb") as fh:
        pickle.dump(mapping_data, fh)

    bundle = load_interval_mapping(str(path))

    assert bundle["metadata"]["strategy"] == "quantile"
    assert "x" in bundle["features"]
    feature_info = bundle["features"]["x"]
    intervals = feature_info["intervals"]
    assert len(intervals) == 2
    assert intervals[0] == pd.Interval(0.0, 5.0, closed="right")
    assert intervals[1] == pd.Interval(5.0, 10.0, closed="right")
    # Quantile strategies should map to string bin codes
    assert feature_info["code_map"][str(intervals[0])] == "0"
    assert feature_info["code_map"][str(intervals[1])] == "1"


def test_discretize_evidence_converts_numeric_to_interval():
    intervals = [pd.Interval(90.0, 130.0, closed="right"), pd.Interval(130.0, 200.0, closed="right")]
    bundle = {
        "metadata": {"strategy": "bnlearn"},
        "features": {
            "trestbps": {
                "intervals": intervals,
                "code_map": {str(intervals[0]): str(intervals[0]), str(intervals[1]): str(intervals[1])},
            }
        },
    }
    evidence = {"trestbps": "128"}

    discretize_evidence(evidence, bundle)

    assert evidence["trestbps"] == str(intervals[0])


def test_discretize_evidence_clamps_bnlearn_out_of_range():
    bundle = {
        "metadata": {"strategy": "bnlearn"},
        "features": {
            "age": {
                "intervals": [pd.Interval(0.0, 50.0, closed="right")],
                "code_map": {"(0.0, 50.0]": "(0.0, 50.0]"},
            }
        },
    }
    evidence = {"age": "120"}

    discretize_evidence(evidence, bundle)
    assert evidence["age"] == "(0.0, 50.0]"


def test_discretize_evidence_quantile_codes():
    intervals = [pd.Interval(0.0, 50.0, closed="right"), pd.Interval(50.0, 100.0, closed="right")]
    bundle = {
        "metadata": {"strategy": "quantile"},
        "features": {
            "feature": {
                "intervals": intervals,
                "code_map": {str(intervals[0]): "0", str(intervals[1]): "1"},
            }
        },
    }
    evidence = {"feature": "75"}

    discretize_evidence(evidence, bundle)

    assert evidence["feature"] == "1"


def test_discretize_evidence_handles_out_of_range():
    intervals = [
        pd.Interval(-10.0, 0.0, closed="right"),
        pd.Interval(0.0, 10.0, closed="right"),
    ]
    bundle = {
        "metadata": {"strategy": "quantile"},
        "features": {
            "feature": {
                "intervals": intervals,
                "code_map": {str(intervals[0]): "0", str(intervals[1]): "1"},
            }
        },
    }

    evidence_low = {"feature": "-50"}
    discretize_evidence(evidence_low, bundle)
    assert evidence_low["feature"] == "0"

    evidence_high = {"feature": "50"}
    discretize_evidence(evidence_high, bundle)
    assert evidence_high["feature"] == "1"

