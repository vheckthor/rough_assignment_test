"""
BN config loader (new file).

Builds a BNModel compatible with enumeration.py from saved config files
written by BNModel.write_config (which uses CPT(...) sections).
"""
from __future__ import annotations

from typing import Dict, List, Tuple
import os

from bayesian_net.src.parameter_learning.cpt_generator import BNModel


def _parse_structure(structure_items: List[str]) -> List[Tuple[str, str]]:
    edges: List[Tuple[str, str]] = []
    for item in structure_items:
        s = item.strip()
        if not s or not s.startswith("P(") or not s.endswith(")"):
            continue
        inner = s[2:-1]
        if "|" in inner:
            child, parents_str = inner.split("|", 1)
            child = child.strip()
            parents = [p.strip() for p in parents_str.split(",") if p.strip()]
            for p in parents:
                edges.append((p, child))
    return edges


def _toposort(variables: List[str], edges: List[Tuple[str, str]]) -> List[str]:
    from collections import defaultdict, deque
    indeg = {v: 0 for v in variables}
    adj: Dict[str, List[str]] = defaultdict(list)
    for u, v in edges:
        if u in indeg and v in indeg:
            adj[u].append(v)
            indeg[v] += 1
    q = deque([v for v, d in indeg.items() if d == 0])
    order: List[str] = []
    while q:
        u = q.popleft()
        order.append(u)
        for w in adj[u]:
            indeg[w] -= 1
            if indeg[w] == 0:
                q.append(w)
    if len(order) < len(variables):
        order.extend([v for v in variables if v not in order])
    return order


def load_bnmodel_from_config(config_path: str) -> BNModel:
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Config not found: {config_path}")

    with open(config_path, "r") as f:
        lines = [ln.rstrip("\n") for ln in f]

    random_variables: List[str] = []
    structure_items: List[str] = []
    cpts: Dict[str, Dict[str, float]] = {}

    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line:
            i += 1
            continue
        if line.startswith("random_variables:"):
            rv_str = line.split(":", 1)[1].strip()
            random_variables = [x for x in rv_str.split(";") if x]
            i += 1
            continue
        if line.startswith("structure:"):
            st_str = line.split(":", 1)[1].strip()
            structure_items = [x for x in st_str.split(";") if x]
            i += 1
            continue
        if line.startswith("CPT("):
            header = line.split(":", 1)[0]  # e.g., CPT(X|A,B)
            pkey = "P" + header[3:]        # -> P(X|A,B)
            cpts[pkey] = {}
            i += 1
            while i < len(lines):
                row = lines[i].strip().rstrip(";")
                if (not row) or row.startswith("CPT(") or row.startswith("random_variables:") or row.startswith("structure:"):
                    if row.startswith("CPT("):
                        i -= 1
                    break
                if "=" in row:
                    k, v = row.split("=", 1)
                    k = k.strip()
                    v = v.strip()
                    try:
                        cpts[pkey][k] = float(v)
                    except ValueError:
                        pass
                i += 1
        i += 1

    if not random_variables:
        raise ValueError("random_variables missing in config")

    edges = _parse_structure(structure_items)
    model = BNModel(random_variables=random_variables, edges=edges)
    model.cpts = cpts

    # derive rv_values from CPT tables
    model.rv_values = {v: [] for v in random_variables}
    for pkey, table in cpts.items():
        var = pkey[2:-1] if "|" not in pkey else pkey[2:pkey.index("|")]
        vals = set()
        for ek in table.keys():
            vals.add(ek.split("|")[0].strip())
        if vals:
            model.rv_values[var] = sorted(vals)

    model.random_variables = _toposort(model.random_variables, model.edges)
    return model


