import os
from typing import Any, Dict, List, Optional
import pandas as pd


from bayesian_net.src.utils.comparism_enum import ComparismTypeEnum
from bayesian_net.src.reporting import aggregate_results
from bayesian_net.src.utils.data_manager import DataManager
from bayesian_net.src.utils.structure_enum import CI_TestEnum, ScoreEnum, StructureTypeEnum
from bayesian_net.src.comparisms.algorithm_comparism import algorithm_comparism
from bayesian_net.src.comparisms.ci_test_comparism import ci_test_comparism
from bayesian_net.src.comparisms.scoring_comparism import score_comparism
from bayesian_net.src.comparisms.hybrid_comparism import hybrid_mm_hillclimb_with_score_comparism
from bayesian_net.src.best_computation import best_computation_results


def get_best_results(per_fold_csv: str, 
    processed_data: Dict[str, Any], result_paths: Dict[str, Any], 
    target_col: str, max_iter: int, max_bnlearn_rows: int, csv_path: str) -> Dict[str, Any]:

    best_results = pd.read_csv(per_fold_csv).sort_values(by=['bal_acc', 'f1', 'auc'], ascending=False).head(1)
    print(best_results)
    best_result = best_results.iloc[0]
    print("=========Best Result Columns=================")
    print(best_result)
    best_method = StructureTypeEnum(best_result['method'])
    best_score = None
    if best_method == StructureTypeEnum.PC_STABLE:
        best_score = CI_TestEnum(best_result.get('score', CI_TestEnum.CHI_SQUARE))
    else:
        best_score = ScoreEnum(best_result.get('score', ScoreEnum.AIC.value))

    # best_ci_test = CI_TestEnum(best_result.get('ci_test', CI_TestEnum.CHI_SQUARE.value))
    best_discretizer = best_result['discretizer']
    best_bins = best_result['bins']

    images_dir = result_paths['images_dir']
    png_path = os.path.join(images_dir, f"dag_{best_method.value}_{best_score.value}_best.png")


    #load the train and test csvs from processed folder
    train_csv = processed_data['train_path']
    test_csv = processed_data['test_path']
    #load the train and test data from the csvs
    train_data = pd.read_csv(train_csv)
    test_data = pd.read_csv(test_csv)
    #run the best computation
    return best_computation_results(
        train_data, test_data, 
        target_col, 
        best_discretizer, 
        best_bins, 
        best_method, 
        max_iter, 
        max_bnlearn_rows, 
        png_path, 
        result_paths, 
        best_score,
        best_score,
        csv_path)


def run_experiment(
    csv_path: str,
    comparism_type: ComparismTypeEnum,
    target_col: Optional[str] = None,
    n_splits: int = 5,
    seed: int = 42,
    methods: List[StructureTypeEnum] = [StructureTypeEnum.HILLCLIMB, StructureTypeEnum.PC_STABLE],
    score_type: ScoreEnum = ScoreEnum.AIC,
    ci_test: CI_TestEnum = CI_TestEnum.CHI_SQUARE,
    max_iter: int = 20_000_000,
    bins: int = 4,
    train_ratio: float = 0.8,
    discretizer: str = 'bnlearn',
    max_bnlearn_rows: int = 30_000,
):
    # Initialize data manager and process dataset
    print(f"Running experiment with comparism type: {comparism_type}")
    data_manager = DataManager(seed=seed, train_ratio=train_ratio)

    processed_data = data_manager.process_dataset(csv_path, target_col, should_split=True)
    target_col = processed_data['target_col']

    discretizer = (discretizer or 'bnlearn').lower()

    result_paths = processed_data['result_paths']
    aggregate_cols = []
    # Extract result paths for easier access
    per_fold_csv = result_paths['per_fold_csv']
    summary_csv = result_paths['summary_csv']
    try:
        match comparism_type:
            case ComparismTypeEnum.SCORE_VS_CONSTRAINT_BASED:
                score_type = ScoreEnum.AIC
                ci_test = CI_TestEnum.CHI_SQUARE
                algorithm_comparism(
                    processed_data,
                    csv_path,
                    n_splits,
                    seed,
                    bins,
                    methods,
                    score_type,
                    ci_test,
                    max_iter=max_iter,
                    discretizer=discretizer,
                    max_bnlearn_rows=max_bnlearn_rows,
                )
                aggregate_cols = ['dataset', 'method']
            case ComparismTypeEnum.SCORE_VS_SCORE_BASED:
                print("Running score vs score based comparism")
                method = StructureTypeEnum.HILLCLIMB 
                score_types = [ScoreEnum.AIC, ScoreEnum.BIC, ScoreEnum.BDEU, ScoreEnum.K2, ScoreEnum.BDS]
                score_comparism(
                    processed_data,
                    csv_path,
                    n_splits,
                    seed,
                    bins,
                    method,
                    score_types,
                    max_iter,
                    discretizer=discretizer,
                    max_bnlearn_rows=max_bnlearn_rows,
                )
                aggregate_cols = ['dataset', 'score']
            case ComparismTypeEnum.HYBRID_MM_HILLCLIMB_WITH_SCORE:
                method = StructureTypeEnum.HYBRID_MM_HILLCLIMB_WITH_SCORE
                score_types = [ScoreEnum.AIC, ScoreEnum.BIC, ScoreEnum.BDEU, ScoreEnum.K2, ScoreEnum.BDS]
                hybrid_mm_hillclimb_with_score_comparism(
                    processed_data,
                    csv_path,
                    n_splits,
                    seed,
                    bins,
                    method,
                    score_types,
                    ci_test,
                    max_iter,
                    discretizer=discretizer,
                    max_bnlearn_rows=max_bnlearn_rows,
                )
                aggregate_cols = ['dataset', 'score']
            case ComparismTypeEnum.CONSTRAINT_BASED:
                method = StructureTypeEnum.PC_STABLE
                ci_tests = [ci for ci in CI_TestEnum]
                ci_test_comparism(
                    processed_data,
                    csv_path,
                    n_splits,
                    seed,
                    bins,
                    method,
                    ci_tests,
                    discretizer=discretizer,
                    max_bnlearn_rows=max_bnlearn_rows,
                )
                aggregate_cols = ['dataset', 'ci_test']
            case _:
                raise ValueError(f"Unknown comparism type: {comparism_type}")
        # Aggregate results
        aggregate_results(per_fold_csv, summary_csv, group_cols=aggregate_cols)
        print(f"Wrote per-fold results to {per_fold_csv}")
        print(f"Wrote summary to {summary_csv}")

        best_results = get_best_results(per_fold_csv, processed_data, result_paths, target_col, max_iter, max_bnlearn_rows, csv_path)
        best_results_csv = result_paths['best_results_csv']
        pd.DataFrame([best_results]).to_csv(best_results_csv, index=False)
        print(f"Wrote best results to {best_results}")

    except Exception as e:
        print(f"Error running experiment: {e}")


if __name__ == "__main__":
    pass

