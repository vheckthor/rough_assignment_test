import os

from src.inference.bayes_net_probabilistic_inference import ProbabilisticInference


QUIT_CHOICES = {"q", "quit", "exit"}


def _configs_dir() -> str:
    return os.path.join(os.path.dirname(__file__), "configs")


def _find_config_candidates(keyword: str) -> list[str]:
    configs_directory = _configs_dir()
    if not os.path.isdir(configs_directory):
        return []

    keyword_lower = keyword.lower()
    matches: list[str] = []
    for entry in os.listdir(configs_directory):
        entry_lower = entry.lower()
        if not entry_lower.endswith(".txt"):
            continue
        if keyword_lower in entry_lower and "best" in entry_lower:
            matches.append(os.path.join(configs_directory, entry))
    return sorted(matches)


def _auto_resolve_config(keyword: str) -> str | None:
    matches = _find_config_candidates(keyword)
    if not matches:
        print(f"No config file containing '{keyword}' and 'best' was found in configs directory.")
        return None

    if len(matches) == 1:
        chosen = matches[0]
        print(f"Automatically selected config: {chosen}")
        return chosen

    print(f"Multiple config files found for '{keyword}' with 'best':")
    for idx, match in enumerate(matches, start=1):
        print(f"  [{idx}] {os.path.basename(match)}")

    while True:
        try:
            selection = input(
                "Select a config by number, press Enter for the first option, or 'q' to quit: "
            ).strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting interactive shell.")
            return None

        if selection == "":
            chosen = matches[0]
            print(f"Using config: {chosen}")
            return chosen

        if selection.lower() in QUIT_CHOICES:
            print("Goodbye.")
            return None

        if selection.isdigit():
            index = int(selection)
            if 1 <= index <= len(matches):
                chosen = matches[index - 1]
                print(f"Using config: {chosen}")
                return chosen

        print("Invalid selection. Please try again.")


def _mappings_dir() -> str:
    return os.path.join(_configs_dir(), "interval_mapping")


def _find_mapping_candidates(keyword: str) -> list[str]:
    mapping_dir = _mappings_dir()
    if not os.path.isdir(mapping_dir):
        return []

    keyword_lower = keyword.lower()
    matches: list[str] = []
    for entry in os.listdir(mapping_dir):
        entry_lower = entry.lower()
        if not entry_lower.endswith(('.pkl', '.pickle')):
            continue
        if keyword_lower in entry_lower and "best" in entry_lower:
            matches.append(os.path.join(mapping_dir, entry))
    return sorted(matches)


def _auto_resolve_mapping(keyword: str) -> str | None:
    matches = _find_mapping_candidates(keyword)
    if not matches:
        print(f"No discretisation mapping containing '{keyword}' and 'best' was found in configs/interval_mapping.")
        return None

    if len(matches) == 1:
        chosen = matches[0]
        print(f"Automatically selected mapping: {chosen}")
        return chosen

    print(f"Multiple mappings found for '{keyword}' with 'best':")
    for idx, match in enumerate(matches, start=1):
        print(f"  [{idx}] {os.path.basename(match)}")

    while True:
        try:
            selection = input(
                "Select a mapping by number, press Enter for the first option, or 'q' to quit: "
            ).strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting interactive shell.")
            return None

        if selection == "":
            chosen = matches[0]
            print(f"Using mapping: {chosen}")
            return chosen

        if selection.lower() in QUIT_CHOICES:
            print("Goodbye.")
            return None

        if selection.isdigit():
            index = int(selection)
            if 1 <= index <= len(matches):
                chosen = matches[index - 1]
                print(f"Using mapping: {chosen}")
                return chosen

        print("Invalid selection. Please try again.")


def _prompt_manual_config() -> str | None:
    prompt = "Enter path to Bayesian network config file (blank to re-open menu, 'q' to quit): "

    while True:
        try:
            user_input = input(prompt).strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting interactive shell.")
            return None

        if user_input == "":
            return None

        if user_input.lower() in QUIT_CHOICES:
            print("Goodbye.")
            return None

        resolved = _resolve_path(user_input)
        if resolved is not None:
            return resolved

        print(f"Could not find config file '{user_input}'. Please try again.")


def _obtain_config(initial_path: str | None) -> tuple[str | None, str | None]:
    config = _resolve_path(initial_path)
    if config is not None:
        return config, None

    menu = (
        "Select evaluation dataset:\n"
        "  [1] Heart (default)\n"
        "  [2] Fraud\n"
        "  [3] Other\n"
        "Enter choice (press Enter for Heart, 'q' to quit): "
    )

    while True:
        try:
            selection = input(menu).strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting interactive shell.")
            return None, None

        if selection == "":
            selection = "1"

        selection_lower = selection.lower()
        if selection_lower in QUIT_CHOICES:
            print("Goodbye.")
            return None, None

        if selection_lower in {"1", "heart", "h"}:
            keyword = "heart"
        elif selection_lower in {"2", "fraud", "f"}:
            keyword = "fraud"
        elif selection_lower in {"3", "other", "o", "others"}:
            keyword = None
        else:
            print("Unrecognised selection. Please choose 1, 2, or 3.")
            continue

        if keyword is not None:
            config = _auto_resolve_config(keyword)
            if config is not None:
                return config, keyword
            print("Unable to auto-resolve config. Please provide the path manually.")

        manual_config = _prompt_manual_config()
        if manual_config is not None:
            return manual_config, keyword


def _prompt_manual_mapping() -> str | None:
    prompt = "Enter path to discretization mapping (blank to continue without mapping, 'q' to quit): "

    while True:
        try:
            mapping_input = input(prompt).strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting interactive shell.")
            return None

        if mapping_input == "":
            print("Proceeding without a mapping. Raw numeric evidence must already match CPT labels.")
            return ""

        if mapping_input.lower() in QUIT_CHOICES:
            print("Goodbye.")
            return None

        resolved = _resolve_path(mapping_input)
        if resolved is not None:
            return resolved

        print(f"Could not find mapping file '{mapping_input}'. Please try again.")



def _resolve_path(path: str | None) -> str | None:
    """Return an absolute path if the supplied path exists, otherwise None."""
    if not path:
        return None
    if os.path.exists(path):
        return os.path.abspath(path)
    candidate = os.path.join(os.getcwd(), path)
    return os.path.abspath(candidate) if os.path.exists(candidate) else None


def interactive_shell(config_path, mapping_path=None, default_samples=1000, verbose=False):
    """Simple command-line loop for running repeated inference queries."""

    config, dataset_keyword = _obtain_config(config_path)
    if config is None:
        return

    if default_samples is None:
        default_samples = 10_000

    mapping = _resolve_path(mapping_path)
    if mapping_path and mapping is None:
        print("Warning: Could not locate mapping '%s'." % mapping_path)

    if mapping is None and dataset_keyword:
        mapping = _auto_resolve_mapping(dataset_keyword)

    while mapping is None:
        manual_mapping = _prompt_manual_mapping()
        if manual_mapping is None:
            return
        if manual_mapping == "":
            break
        mapping = manual_mapping

    print("\nInteractive Bayesian Network inference shell")
    print("Config file:", config)
    if mapping:
        print("Discretisation mapping:", mapping)
    else:
        print("Discretisation mapping: <none>")
    print("Type 'q' at any prompt to exit.\n")

    while True:
        try:
            alg_choice = input(
                "Select algorithm [1] Inference by Enumeration, [2] Rejection Sampling (q to quit): "
            ).strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting interactive shell.")
            break

        if alg_choice.lower() in {"q", "quit", "exit"}:
            print("Goodbye.")
            break

        if alg_choice in {"1", "e", "E"}:
            alg_name = "InferenceByEnumeration"
        elif alg_choice in {"2", "r", "R"}:
            alg_name = "RejectionSampling"
        else:
            print("Unrecognised selection '%s'. Please choose 1 or 2." % alg_choice)
            continue

        try:
            query = input(
                "Enter probabilistic query (e.g. P(target|sex=0,trestbps=128)):\n> "
            ).strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting interactive shell.")
            break

        if not query:
            print("Query cannot be empty. Try again.")
            continue

        if query.lower() in {"q", "quit", "exit"}:
            print("Goodbye.")
            break

        num_samples = None
        if alg_name == "RejectionSampling":
            prompt = "Number of samples [%s]: " % (default_samples)
            try:
                sample_input = input(prompt).strip()
            except (EOFError, KeyboardInterrupt):
                print("\nExiting interactive shell.")
                break

            if sample_input.lower() in {"q", "quit", "exit"}:
                print("Goodbye.")
                break

            if sample_input:
                try:
                    num_samples = int(sample_input)
                    if num_samples <= 0:
                        raise ValueError
                except ValueError:
                    print("Invalid number of samples. Please enter a positive integer.")
                    continue
            else:
                num_samples = default_samples

        print("\n--- Running %s ---" % alg_name)
        try:
            ProbabilisticInference(
                alg_name,
                config,
                query,
                num_samples=num_samples,
                mapping_path=mapping,
                verbose=verbose,
            )
        except Exception as exc:  # pragma: no cover - defensive
            print("ERROR: %s" % exc)
        print("--- Done ---\n")

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Run probabilistic inference on a Bayesian Network configuration."
    )
    parser.add_argument(
        "alg_name",
        nargs="?",
        help="Inference algorithm to run (InferenceByEnumeration or RejectionSampling).",
    )
    parser.add_argument(
        "file_name",
        nargs="?",
        help="Path to the Bayesian network configuration file (CPT).",
    )
    parser.add_argument(
        "prob_query",
        nargs="?",
        help="Probabilistic query, e.g. 'P(target|sex=0,trestbps=128)'.",
    )
    parser.add_argument(
        "--num-samples",
        dest="num_samples",
        type=int,
        default=None,
        help="Number of samples for sampling-based algorithms (e.g. rejection sampling).",
    )
    parser.add_argument(
        "--mapping",
        dest="mapping_path",
        help="Pickle file containing discretization intervals to map raw evidence values.",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose logging for debugging purposes.",
    )
    parser.add_argument(
        "--interactive",
        action="store_true",
        help="Launch an interactive shell instead of running a single query.",
    )

    args = parser.parse_args()

    if args.interactive:
        config_path = args.file_name
        if config_path is None and args.alg_name is not None:
            potential_path = args.alg_name
            if potential_path and os.path.exists(potential_path):
                config_path = potential_path
        interactive_shell(
            config_path,
            mapping_path=args.mapping_path,
            default_samples=args.num_samples,
            verbose=args.verbose,
        )
    else:
        missing = []
        if args.alg_name is None:
            missing.append("algorithm name")
        if args.file_name is None:
            missing.append("config file")
        if args.prob_query is None:
            missing.append("probabilistic query")
        if missing:
            parser.error(
                "Missing required arguments: %s (or use --interactive)."
                % ", ".join(missing)
            )

        config_file = _resolve_path(args.file_name)
        if config_file is None:
            raise FileNotFoundError(
                f"Could not find config file '{args.file_name}'."
            )

        resolved_mapping = _resolve_path(args.mapping_path)
        if args.mapping_path and resolved_mapping is None:
            raise FileNotFoundError(
                f"Could not find mapping file '{args.mapping_path}'."
            )

        ProbabilisticInference(
            args.alg_name,
            config_file,
            args.prob_query,
            num_samples=args.num_samples,
            mapping_path=resolved_mapping,
            verbose=args.verbose,
        )
