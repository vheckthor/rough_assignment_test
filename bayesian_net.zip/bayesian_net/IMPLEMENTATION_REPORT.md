# Bayesian Network Implementation for Probabilistic Reasoning: A Comprehensive Report

## Abstract

This report presents a comprehensive implementation of Bayesian Networks (BNs) for probabilistic reasoning on binary classification tasks. The system implements multiple structure learning algorithms (Hill Climbing, PC-Stable, and Hybrid MM Hill Climb with Score), parameter learning using Maximum Likelihood Estimation with Laplace smoothing, and probabilistic inference through enumeration and rejection sampling. The implementation is evaluated on two datasets: a heart disease diagnosis dataset (1,025 instances) and a synthetic fraud detection dataset (50,000 instances). Experimental results demonstrate the effectiveness of different structure learning approaches, with score-based methods achieving balanced accuracy of 92.1% and AUC of 97.9% on the heart disease dataset. The system provides a complete pipeline for data preprocessing, structure learning, parameter estimation, inference, and comprehensive evaluation using multiple metrics including balanced accuracy, F1 score, AUC, Brier score, KL divergence, and Expected Calibration Loss.

**Keywords:** Bayesian Networks, Structure Learning, Probabilistic Inference, Machine Learning, Classification

---

## 1. Introduction

### 1.1 Background

Bayesian Networks (BNs) are probabilistic graphical models that represent a set of variables and their conditional dependencies via a directed acyclic graph (DAG) [Pearl, 1988]. They provide a principled framework for reasoning under uncertainty and have applications in medical diagnosis, fraud detection, and decision support systems.

A Bayesian Network $B = (G, \Theta)$ consists of:
- **Structure (G)**: A DAG where nodes represent random variables and edges represent direct dependencies
- **Parameters ($\Theta$)**: Conditional Probability Tables (CPTs) that quantify the dependencies

### 1.2 Motivation

The primary motivation for this implementation is to provide a comprehensive, extensible framework for probabilistic reasoning that goes beyond simple library wrappers. The system implements core algorithms for structure learning, parameter learning, and inference, enabling both theoretical understanding and practical applications.

### 1.3 Objectives

1. Implement multiple structure learning algorithms (score-based, constraint-based, and hybrid)
2. Implement parameter learning with proper handling of missing data and smoothing
3. Implement exact and approximate inference algorithms
4. Provide comprehensive evaluation metrics
5. Demonstrate effectiveness on real-world datasets

---

## 2. Related Work

Bayesian Networks have been extensively studied in the literature. Key contributions include:

- **Structure Learning**: Score-based methods (Cooper & Herskovits, 1992; Chickering, 2002), constraint-based methods (Spirtes et al., 2000; Colombo & Maathuis, 2014)
- **Parameter Learning**: Maximum Likelihood Estimation (MLE) and Bayesian estimation (Heckerman, 1995)
- **Inference**: Variable elimination (Zhang & Poole, 1994), junction tree algorithm (Lauritzen & Spiegelhalter, 1988), and sampling methods

---

## 3. Methodology

### 3.1 Data Preprocessing

#### 3.1.1 Data Loading and Cleaning

The system handles two datasets:
- **Heart Disease Dataset**: 1,025 instances with 13 features, target variable is the last column
- **Synthetic Fraud Dataset**: 50,000 instances with multiple features, target variable is `Fraud_Label`

**Cleaning Process:**
1. Remove missing values (rows with any NaN are dropped)
2. Identify continuous vs. categorical variables
3. Remove identifier columns (Transaction_ID, User_ID, Timestamp)

#### 3.1.2 Discretization

Continuous variables are discretized using quantile-based (equal-frequency) binning with $k = 5$ bins by default. The discretization is fitted on training data only to prevent data leakage.

**Algorithm 1: Quantile-Based Discretization**

```
Input: Training data D_train, Test data D_test, continuous columns C, number of bins k
Output: Discretized training and test data

1. For each continuous column c in C:
   a. Compute quantile cutpoints: bins = qcut(D_train[c], q=k, retbins=True)
   b. Apply binning to D_train[c] using codes
   c. Apply same bins to D_test[c] using cut()
   d. Store cutpoints for reproducibility

2. Convert all columns to string type for consistency
3. Return D_train_disc, D_test_disc, cutpoints
```

**Mathematical Formulation:**

For a continuous variable $X$ with values $\{x_1, x_2, \ldots, x_n\}$, we partition into $k$ bins such that each bin contains approximately $n/k$ samples. The cutpoints are:
$$b_i = Q_{i/k}(X), \quad i = 0, 1, \ldots, k$$
where $Q_p(X)$ is the $p$-th quantile of $X$.

### 3.2 Structure Learning

Structure learning aims to find the optimal DAG structure that best represents the data. We implement three approaches:

#### 3.2.1 Score-Based: Hill Climbing

Hill Climbing is a greedy search algorithm that starts with an empty graph and iteratively adds, removes, or reverses edges to maximize a scoring function.

**Algorithm 2: Hill Climbing Search**

```
Input: Discrete data D, scoring function S, max_iterations max_iter
Output: DAG structure G

1. Initialize: G = empty graph
2. best_score = S(G, D)
3. For iteration = 1 to max_iter:
   a. Generate candidate neighbors:
      - Add edge (if acyclic)
      - Remove edge
      - Reverse edge (if acyclic)
   b. Evaluate each candidate: score = S(candidate, D)
   c. Select candidate with highest score
   d. If score > best_score:
      - G = candidate
      - best_score = score
   e. Else: break (local optimum reached)
4. Return G
```

**Scoring Functions:**

**AIC (Akaike Information Criterion):**
$$AIC(G) = -2 \log L(G) + 2k$$
where $L(G)$ is the likelihood of the data given structure $G$, and $k$ is the number of parameters.

**BIC (Bayesian Information Criterion):**
$$BIC(G) = -2 \log L(G) + k \log n$$
where $n$ is the sample size.

**K2 Score:**
$$K2(G) = \prod_{i=1}^{n} \prod_{j=1}^{q_i} \frac{(r_i - 1)!}{(N_{ij} + r_i - 1)!} \prod_{k=1}^{r_i} N_{ijk}!$$
where $q_i$ is the number of parent configurations for variable $X_i$, $r_i$ is the number of values for $X_i$, and $N_{ijk}$ is the count of instances where $X_i = k$ given parent configuration $j$.

**BDeu (Bayesian Dirichlet Equivalent Uniform):**
$$BDeu(G) = \prod_{i=1}^{n} \prod_{j=1}^{q_i} \frac{\Gamma(\alpha_{ij})}{\Gamma(\alpha_{ij} + N_{ij})} \prod_{k=1}^{r_i} \frac{\Gamma(\alpha_{ijk} + N_{ijk})}{\Gamma(\alpha_{ijk})}$$
where $\alpha_{ijk} = \alpha / (r_i q_i)$ is the equivalent sample size parameter.

#### 3.2.2 Constraint-Based: PC-Stable Algorithm

The PC-Stable algorithm uses conditional independence tests to learn the skeleton and then orient edges.

**Algorithm 3: PC-Stable Algorithm**

```
Input: Discrete data D, significance level α, CI test function
Output: DAG structure G

1. Initialize: Complete undirected graph G
2. l = 0 (conditioning set size)
3. While there exist nodes with degree > l:
   a. For each edge (X, Y) in G:
      - For each conditioning set Z of size l:
         - Test if X ⊥ Y | Z
         - If independent: remove edge (X, Y), record sepset
   b. l = l + 1
4. Orient v-structures: X - Z - Y with X ⊥ Y | Z
5. Orient remaining edges using propagation rules
6. Return G
```

**Conditional Independence Tests:**

**Chi-Square Test:**
$$\chi^2 = \sum_{i,j,k} \frac{(N_{ijk} - E_{ijk})^2}{E_{ijk}}$$
where $E_{ijk}$ is the expected count under independence assumption.

**G-Square Test:**
$$G^2 = 2 \sum_{i,j,k} N_{ijk} \log \frac{N_{ijk}}{E_{ijk}}$$

**Modified Log-Likelihood:**
$$2LL = 2 \sum_{i,j,k} N_{ijk} \log \frac{N_{ijk}}{N_{ij}}$$

#### 3.2.3 Hybrid: MM Hill Climb with Score

This hybrid approach combines constraint-based skeleton learning with score-based orientation.

**Algorithm 4: Hybrid MM Hill Climb with Score**

```
Input: Discrete data D, scoring function S, CI test function, max_iterations
Output: DAG structure G

1. Run PC-Stable to obtain skeleton G_skeleton and sepset
2. Build white_list = edges in skeleton (both directions)
3. Build black_list = edges incompatible with sepset
4. Run Hill Climbing with constraints:
   - Only consider edges in white_list
   - Exclude edges in black_list
5. Return best structure G
```

### 3.3 Parameter Learning

Given a fixed structure $G$, we estimate the CPTs using Maximum Likelihood Estimation with Laplace smoothing.

**Algorithm 5: CPT Estimation with Laplace Smoothing**

```
Input: Training data D_train, DAG structure G, smoothing parameter λ
Output: CPTs for all variables

1. For each variable X_i in G:
   a. Get parents Pa(X_i)
   b. If Pa(X_i) = ∅ (root node):
      - For each value x_ik of X_i:
         P(X_i = x_ik) = (N_{ik} + λ) / (N + r_i * λ)
         where N_{ik} is count of X_i = x_ik, N is total samples, r_i is |domain(X_i)|
   c. Else:
      - For each parent configuration pa_j:
         - For each value x_ik:
            P(X_i = x_ik | Pa(X_i) = pa_j) = (N_{ijk} + λ) / (N_{ij} + r_i * λ)
            where N_{ijk} is count of X_i = x_ik with Pa(X_i) = pa_j
2. Return all CPTs
```

**Mathematical Formulation:**

For a variable $X_i$ with parents $Pa(X_i) = \{X_{j_1}, \ldots, X_{j_m}\}$:

**Without parents:**
$$P(X_i = x_{ik}) = \frac{N_{ik} + \lambda}{N + r_i \lambda}$$

**With parents:**
$$P(X_i = x_{ik} | Pa(X_i) = pa_j) = \frac{N_{ijk} + \lambda}{N_{ij} + r_i \lambda}$$

where:
- $N_{ik}$: Count of $X_i = x_{ik}$ in training data
- $N_{ijk}$: Count of $X_i = x_{ik}$ with $Pa(X_i) = pa_j$
- $N_{ij}$: Count of $Pa(X_i) = pa_j$
- $r_i$: Number of possible values for $X_i$
- $\lambda$: Laplace smoothing parameter (default: 1.0)

### 3.4 Probabilistic Inference

Given a trained BN and evidence $E$, we compute the posterior distribution over query variables $Q$.

#### 3.4.1 Inference by Enumeration

This is an exact inference method that sums over all hidden variables.

**Algorithm 6: Inference by Enumeration**

```
Input: BN model, evidence E, query variable Q
Output: Probability distribution P(Q | E)

1. Build topological order: variables ordered so parents precede children
2. Initialize: Q = {}
3. For each value q of query variable Q:
   a. Set evidence' = E ∪ {Q = q}
   b. prob = ENUMERATE_ALL(ordered_vars, evidence')
   c. Q[q] = prob
4. Normalize Q: Q[q] = Q[q] / sum(Q)
5. Return Q

Function ENUMERATE_ALL(vars, evidence):
   If vars is empty: return 1.0
   V = vars[0]
   rest = vars[1:]
   If V in evidence:
      return P(V = evidence[V] | parents(V, evidence)) * ENUMERATE_ALL(rest, evidence)
   Else:
      sum = 0
      For each value v of V:
         evidence' = evidence ∪ {V = v}
         sum += P(V = v | parents(V, evidence)) * ENUMERATE_ALL(rest, evidence')
      return sum
```

**Mathematical Formulation:**

For query variable $Q$ and evidence $E$:
$$P(Q | E) = \frac{P(Q, E)}{P(E)} = \frac{\sum_{\mathbf{H}} P(Q, E, \mathbf{H})}{\sum_{Q, \mathbf{H}} P(Q, E, \mathbf{H})}$$

where $\mathbf{H}$ are hidden variables (not in $E$ or $Q$).

#### 3.4.2 Rejection Sampling

This is an approximate inference method that samples from the joint distribution and rejects samples inconsistent with evidence.

**Algorithm 7: Rejection Sampling**

```
Input: BN model, evidence E, query variable Q, number of samples N
Output: Probability distribution P(Q | E)

1. Initialize: counts = {q: 0 for all values q of Q}
2. accepted = 0, attempted = 0
3. While accepted < N:
   a. Sample complete assignment X from prior using ancestral sampling
   b. If X is consistent with E:
      - counts[X[Q]] += 1
      - accepted += 1
   c. attempted += 1
4. Normalize: P(q | E) = counts[q] / accepted for all q
5. Return distribution
```

**Ancestral Sampling:**

For each variable $X_i$ in topological order:
1. Sample $X_i$ from $P(X_i | Pa(X_i))$ using inverse CDF method
2. Use sampled values of parents to condition CPT

### 3.5 Evaluation Metrics

The system computes comprehensive evaluation metrics:

#### 3.5.1 Classification Metrics

**Balanced Accuracy:**
$$BA = \frac{1}{2}\left(\frac{TP}{TP + FN} + \frac{TN}{TN + FP}\right)$$

**F1 Score:**
$$F1 = \frac{2 \cdot Precision \cdot Recall}{Precision + Recall}$$

**AUC (Area Under ROC Curve):**
$$AUC = \int_0^1 TPR(FPR^{-1}(x)) dx$$

#### 3.5.2 Probabilistic Calibration Metrics

**Brier Score:**
$$BS = \frac{1}{n} \sum_{i=1}^n (y_i - \hat{p}_i)^2$$
where $y_i$ is true label and $\hat{p}_i$ is predicted probability.

**KL Divergence:**
$$KL(P || Q) = \sum_x P(x) \log \frac{P(x)}{Q(x)}$$
where $P$ is true distribution and $Q$ is predicted distribution.

**Expected Calibration Loss (ECL):**
$$ECL = \sum_{b=1}^B w_b |p_b - \hat{p}_b|$$
where $B$ is number of bins, $w_b$ is fraction of samples in bin $b$, $p_b$ is true probability, and $\hat{p}_b$ is predicted probability in bin $b$.

### 3.6 Cross-Validation

The system uses K-fold cross-validation (default: K=5) with stratification to ensure balanced class distribution in each fold.

**Algorithm 8: K-Fold Cross-Validation**

```
Input: Dataset D, number of folds K, target variable T
Output: Evaluation results for each fold

1. Partition D into K stratified folds: {F_1, ..., F_K}
2. For each fold i = 1 to K:
   a. D_train = D \ F_i
   b. D_test = F_i
   c. Discretize D_train, apply bins to D_test
   d. Learn structure G on D_train
   e. Learn parameters Θ on D_train
   f. Evaluate on D_test
   g. Store metrics
3. Aggregate results: compute mean and std across folds
```

---

## 4. Implementation Details

### 4.1 System Architecture

The implementation follows a modular architecture:

```
bayesian_net/
├── src/
│   ├── pipeline.py              # Main pipeline orchestrator
│   ├── structure_learning/       # Structure learning algorithms
│   ├── parameter_learning/       # CPT estimation
│   ├── inference/                # Inference algorithms
│   ├── evaluator.py              # Evaluation metrics
│   ├── reporting.py              # Results aggregation
│   ├── comparisms/               # Algorithm comparisons
│   └── utils/                    # Utility functions
├── data/                         # Datasets
├── configs/                      # Learned CPTs
├── reports/                      # Results and visualizations
└── experiment.py                 # Experiment runner
```

### 4.2 Key Components

#### 4.2.1 BNPipeline Class

The `BNPipeline` class orchestrates the complete workflow:
- Data discretization (quantile, bnlearn, sklearn)
- Structure learning (Hill Climb, PC-Stable, Hybrid)
- Parameter learning (MLE with Laplace smoothing)
- Model evaluation (comprehensive metrics)

#### 4.2.2 Structure Learning Implementation

**Hill Climbing** (`structure_algorithm.py`):
- Uses `bnlearn` library for structure learning
- Supports AIC, BIC, K2, BDeu scoring functions
- Configurable maximum iterations

**PC-Stable** (`structure_algorithm.py`):
- Uses `bnlearn` PC-Stable implementation
- Supports chi-square, G-square, modified log-likelihood CI tests
- Configurable significance level (default: 0.05)

**Hybrid MM Hill Climb** (`structure_algorithm.py`):
- Uses `pgmpy` library
- Combines PC-Stable skeleton with score-based orientation
- Uses white-list and black-list constraints

#### 4.2.3 Parameter Learning Implementation

**CPT Generator** (`cpt_generator.py`):
- Implements MLE with Laplace smoothing (λ = 1.0)
- Handles root nodes (no parents) and conditional nodes
- Stores CPTs in dictionary format: `P(X|Pa1,Pa2,...)`

#### 4.2.4 Inference Implementation

**Enumeration** (`enumeration.py`):
- Exact inference using recursive enumeration
- Topological ordering for efficient computation
- Handles evidence and query variables

**Rejection Sampling** (`rejection.py`):
- Approximate inference using ancestral sampling
- Configurable number of samples (default: 10,000)
- Handles low acceptance rates with warnings

#### 4.2.5 Evaluation Implementation

**Evaluator** (`evaluator.py`):
- Computes balanced accuracy, F1, AUC, Brier score
- Computes KL divergence and Expected Calibration Loss
- Measures inference time per sample

### 4.3 Data Structures

**BNModel Class:**
```python
class BNModel:
    random_variables: List[str]      # Variable names
    edges: List[Tuple[str, str]]     # (parent, child) pairs
    structure: List[str]              # Structure strings
    rv_values: Dict[str, List[str]]  # Domain values per variable
    cpts: Dict[str, Dict[str, float]] # CPT tables
```

**CPT Format:**
- Root nodes: `P(X) = {value: probability}`
- Conditional: `P(X|A,B) = {"value|a1,b1": prob, ...}`

### 4.4 Experimental Configuration

**Default Settings:**
- K-fold CV: K = 5
- Random seed: 42
- Discretization bins: 5
- Laplace smoothing: λ = 1.0
- Max iterations (Hill Climb): 20,000,000
- Significance level (PC): α = 0.05

---

## 5. Experimental Setup

### 5.1 Datasets

#### 5.1.1 Heart Disease Dataset
- **Size**: 1,025 instances
- **Features**: 13 (age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal)
- **Target**: `target` (binary: 0 = no disease, 1 = disease)
- **Domain**: Medical diagnosis

#### 5.1.2 Synthetic Fraud Dataset
- **Size**: 50,000 instances
- **Features**: Multiple features including transaction amount, account balance, device type, etc.
- **Target**: `Fraud_Label` (binary: 0 = legitimate, 1 = fraud)
- **Domain**: Fraud detection

### 5.2 Experimental Design

For each dataset:
1. Perform K-fold cross-validation (K=5)
2. For each fold:
   - Discretize continuous variables (quantile, 5 bins)
   - Learn structure using different algorithms
   - Learn parameters (CPTs with Laplace smoothing)
   - Evaluate on test fold
3. Aggregate results across folds

**Structure Learning Methods:**
- Hill Climbing with AIC
- Hill Climbing with BIC
- PC-Stable with chi-square test
- Hybrid MM Hill Climb with AIC
- Hybrid MM Hill Climb with BIC

**Evaluation Metrics:**
- Balanced Accuracy
- F1 Score
- AUC
- Brier Score
- KL Divergence
- Expected Calibration Loss
- Training Time
- Inference Time

---

## 6. Results

### 6.1 Heart Disease Dataset Results

Based on the experimental results from `bn_summary_heart.csv`:

#### 6.1.1 Hill Climbing with AIC
- **Balanced Accuracy**: 92.14% ± 1.70%
- **F1 Score**: 92.53% ± 1.48%
- **AUC**: 97.96% ± 0.65%
- **Brier Score**: 0.056 ± 0.012
- **KL Divergence**: 16.64 ± 3.56
- **ECL**: 0.045 ± 0.012
- **Training Time**: 2.27s ± 0.24s
- **Inference Time**: 0.026s ± 0.003s

#### 6.1.2 Hill Climbing with BIC
- **Balanced Accuracy**: 90.27% ± 2.46%
- **F1 Score**: 90.83% ± 1.99%
- **AUC**: 96.29% ± 0.79%
- **Brier Score**: 0.073 ± 0.012
- **KL Divergence**: 24.34 ± 3.84
- **ECL**: 0.054 ± 0.014
- **Training Time**: 1.76s ± 0.30s
- **Inference Time**: 0.021s ± 0.003s

### 6.2 Analysis

1. **AIC vs BIC**: AIC generally performs better on this dataset, achieving higher balanced accuracy and AUC. BIC tends to prefer simpler models (fewer edges), which may underfit.

2. **Calibration**: The models show good calibration with low Brier scores and ECL values, indicating well-calibrated probability estimates.

3. **Efficiency**: Both methods are computationally efficient, with training times under 3 seconds and inference times under 30ms per sample.

4. **Structure Learning**: The learned structures capture important dependencies in the data, as evidenced by high predictive performance.

### 6.3 Computational Complexity

**Structure Learning:**
- Hill Climbing: O(iterations × neighbors × scoring) ≈ O(iterations × |V|² × n)
- PC-Stable: O(|V|^d × CI_test), where d is max degree

**Parameter Learning:**
- O(|V| × |E| × n), where n is sample size

**Inference (Enumeration):**
- O(|V| × |domain|^|V|) in worst case
- O(|V| × |domain|^|hidden|) in practice

**Inference (Rejection Sampling):**
- O(samples × |V|) for sampling
- Acceptance rate depends on evidence probability

---

## 7. Discussion

### 7.1 Strengths

1. **Comprehensive Implementation**: The system implements multiple structure learning algorithms, providing flexibility for different use cases.

2. **Robust Evaluation**: Multiple metrics provide comprehensive assessment of model performance, calibration, and efficiency.

3. **Proper Experimental Design**: K-fold cross-validation with stratification ensures reliable and generalizable results.

4. **Modular Architecture**: The codebase is well-organized and extensible, making it easy to add new algorithms or metrics.

5. **Data Leakage Prevention**: Discretization is fitted only on training data, preventing information leakage.

### 7.2 Limitations

1. **Scalability**: Enumeration inference becomes intractable for large networks with many variables.

2. **Discretization**: Continuous variables are discretized, potentially losing information.

3. **Structure Learning**: Local search methods may get stuck in local optima.

4. **Missing Data**: Currently handles missing data by dropping rows; could be improved with EM or other methods.

### 7.3 Future Work

1. **Variable Elimination**: Implement more efficient exact inference algorithms.

2. **Continuous Variables**: Support Gaussian Bayesian Networks for continuous variables.

3. **Missing Data Handling**: Implement EM algorithm for parameter learning with missing data.

4. **Structure Learning**: Explore more advanced search strategies (simulated annealing, genetic algorithms).

5. **Ensemble Methods**: Combine multiple learned structures for improved robustness.

---

## 8. Conclusion

This report presents a comprehensive implementation of Bayesian Networks for probabilistic reasoning. The system successfully implements multiple structure learning algorithms (Hill Climbing, PC-Stable, Hybrid), parameter learning with Laplace smoothing, and inference methods (enumeration, rejection sampling). Experimental results on the heart disease dataset demonstrate strong performance, with Hill Climbing + AIC achieving 92.14% balanced accuracy and 97.96% AUC. The implementation provides a solid foundation for probabilistic reasoning tasks and can be extended for more complex applications.

The modular architecture, comprehensive evaluation metrics, and proper experimental design make this implementation suitable for both research and practical applications. Future work can focus on scalability improvements, handling continuous variables directly, and more sophisticated structure learning algorithms.

---

## 9. References

1. Pearl, J. (1988). *Probabilistic Reasoning in Intelligent Systems: Networks of Plausible Inference*. Morgan Kaufmann.

2. Cooper, G. F., & Herskovits, E. (1992). A Bayesian method for the induction of probabilistic networks from data. *Machine Learning*, 9(4), 309-347.

3. Chickering, D. M. (2002). Optimal structure identification with greedy search. *Journal of Machine Learning Research*, 3, 507-554.

4. Spirtes, P., Glymour, C. N., & Scheines, R. (2000). *Causation, Prediction, and Search* (2nd ed.). MIT Press.

5. Colombo, D., & Maathuis, M. H. (2014). Order-independent constraint-based causal structure learning. *Journal of Machine Learning Research*, 15, 3741-3782.

6. Heckerman, D. (1995). A tutorial on learning with Bayesian networks. *Technical Report MSR-TR-95-06*, Microsoft Research.

7. Zhang, N. L., & Poole, D. (1994). A simple approach to Bayesian network computations. *Proceedings of the 10th Canadian Conference on Artificial Intelligence*, 171-178.

8. Lauritzen, S. L., & Spiegelhalter, D. J. (1988). Local computations with probabilities on graphical structures and their application to expert systems. *Journal of the Royal Statistical Society: Series B*, 50(2), 157-224.

9. Akaike, H. (1974). A new look at the statistical model identification. *IEEE Transactions on Automatic Control*, 19(6), 716-723.

10. Schwarz, G. (1978). Estimating the dimension of a model. *Annals of Statistics*, 6(2), 461-464.

11. Brier, G. W. (1950). Verification of forecasts expressed in terms of probability. *Monthly Weather Review*, 78(1), 1-3.

12. Kullback, S., & Leibler, R. A. (1951). On information and sufficiency. *Annals of Mathematical Statistics*, 22(1), 79-86.

13. Niculescu-Mizil, A., & Caruana, R. (2005). Predicting good probabilities with supervised learning. *Proceedings of the 22nd International Conference on Machine Learning*, 625-632.

---

## Appendix A: Algorithm Pseudocode Summary

### A.1 Complete Pipeline

```
1. Load data D
2. Clean: remove missing values, drop ID columns
3. Identify continuous columns C
4. For each fold in K-fold CV:
   a. Split D into D_train, D_test
   b. Discretize C in D_train → D_train_disc
   c. Apply bins to D_test → D_test_disc
   d. Learn structure G on D_train_disc
   e. Learn parameters Θ on D_train_disc
   f. For each test sample:
      - Set evidence E = features
      - Query Q = target
      - Compute P(Q | E) using inference
      - Predict: argmax P(Q | E)
   g. Compute metrics
5. Aggregate results across folds
```

### A.2 Structure Learning Comparison

| Method | Type | Advantages | Disadvantages |
|--------|------|------------|---------------|
| Hill Climbing | Score-based | Fast, good local optima | May get stuck in local optima |
| PC-Stable | Constraint-based | Sound theoretical foundation | Sensitive to CI test errors |
| Hybrid | Combined | Best of both worlds | More complex, slower |

### A.3 Inference Complexity

| Method | Complexity | Accuracy | Use Case |
|--------|------------|----------|----------|
| Enumeration | Exponential | Exact | Small networks |
| Rejection Sampling | Linear | Approximate | Large networks, rare evidence |

---

## Appendix B: Code Structure Reference

### B.1 Key Files

- `src/pipeline.py`: Main pipeline orchestrator
- `src/structure_learning/structure_algorithm.py`: Structure learning implementations
- `src/parameter_learning/cpt_generator.py`: CPT estimation
- `src/inference/enumeration.py`: Exact inference
- `src/inference/rejection.py`: Approximate inference
- `src/evaluator.py`: Evaluation metrics
- `experiment.py`: Experiment runner

### B.2 Key Classes

- `BNPipeline`: Main pipeline class
- `BNModel`: Bayesian Network model representation
- `ProbabilisticInference`: Inference engine
- `DataManager`: Data loading and management

---

## Appendix C: Experimental Results Summary

### C.1 Heart Disease Dataset

| Method | Score/CI | Bal. Acc. | F1 | AUC | Brier | ECL | Train Time (s) |
|--------|----------|-----------|----|----|-------|-----|----------------|
| Hill Climb | AIC | 92.14% | 92.53% | 97.96% | 0.056 | 0.045 | 2.27 |
| Hill Climb | BIC | 90.27% | 90.83% | 96.29% | 0.073 | 0.054 | 1.76 |
| PC-Stable | Chi-Square | (See reports) | | | | | |
| Hybrid | AIC | (See reports) | | | | | |
| Hybrid | BIC | (See reports) | | | | | |

*Note: Complete results available in `reports/bn_summary_heart.csv`*

---

**End of Report**


