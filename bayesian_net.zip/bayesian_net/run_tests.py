import os
import sys

# Allow running as a script: python bayesian_net/run_tests.py
if __package__ is None or __package__ == "":
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from bayesian_net.src.utils.comparism_enum import ComparismTypeEnum
from bayesian_net.experiment import run_experiment


def main(args):
    # default test on heart.csv in project root or in bayesian_net/data/raw
    candidates = [
        args.csv_path,
        os.path.abspath(os.path.join(os.path.dirname(__file__), '..', args.csv_path)),
    ]
    csv_path = next((p for p in candidates if os.path.isfile(p)), None)
    if csv_path is None:
        raise FileNotFoundError("Could not find heart.csv in bayesian_net/data/raw or project root.")

    print(f"Running BN experiment on {csv_path} ...")
    comparism_type = ComparismTypeEnum(args.comparism_type)
    run_experiment(
        csv_path=csv_path,
        comparism_type=comparism_type,
        target_col=args.target_col,
        n_splits=args.n_splits,
        seed=args.seed,
        bins=args.bins,
        max_iter=args.max_iter,
        discretizer=args.discretizer,
        max_bnlearn_rows=args.max_bnlearn_rows,
    )


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Run Bayesian Network experiments.')
    parser.add_argument('--csv_path', type=str, default='bayesian_net/data/heart.csv', help='Path to the CSV file to use for the experiment.')
    parser.add_argument('--target_col', type=str, default=None, help='Name of the target column to use for the experiment.')
    parser.add_argument('--n_splits', type=int, default=5, help='Number of splits for the experiment.')
    parser.add_argument('--seed', type=int, default=42, help='Seed for the experiment.')
    parser.add_argument('--bins', type=int, default=4, help='Number of bins for the experiment.')
    parser.add_argument('--max_iter', type=int, default=20_000_000, help='Max iterations for hillclimb structure learning. Lower for large datasets.')
    parser.add_argument('--discretizer', type=str, choices=['bnlearn', 'quantile', 'sklearn'], default='sklearn', help='Discretization strategy to use. Default uses bnlearn; quantile uses pandas qcut.')
    parser.add_argument('--max_bnlearn_rows', type=int, default=50_000, help='Maximum dataset size to run bnlearn discretization on before falling back to quantile discretizer.')
    parser.add_argument(
        '--comparism_type',
        type=str,
        choices=[c.value for c in ComparismTypeEnum],
        default=ComparismTypeEnum.SCORE_VS_SCORE_BASED.value,
        help='Type of comparism to use for the experiment. Options: score_vs_score_based, score_vs_constraint_based, constraint_based. Default: score_vs_score_based.',
    )
    args = parser.parse_args()
    main(args)
