import dask.dataframe as dd

def preprocess_with_dask(file_path: str, target: str = None, low_thresh: int = 10, high_thresh: int = 50) -> dd.DataFrame:
    df = dd.read_csv(file_path, assume_missing=True)  # safer dtype inference
    print(df.dtypes)
    target = target or df.columns[-1]
    print(f"Target column: {target}")

    # Identify categorical columns
    object_cols = [col for col, dtype in df.dtypes.items() if "string" in str(dtype)]

    categorical_cols = [col for col in object_cols if col != target]

    if not categorical_cols:
        print("No categorical columns found for encoding.")
        return df

    # Compute cardinality safely
    cardinality = {}
    for col in categorical_cols:
        try:
            cardinality[col] = df[col].nunique().compute()
        except Exception as e:
            print(f"Skipping column {col} due to error: {e}")

    low_card = [col for col in categorical_cols if cardinality.get(col, 0) <= low_thresh]
    mid_card = [col for col in categorical_cols if low_thresh < cardinality.get(col, 0) <= high_thresh]
    high_card = [col for col in categorical_cols if cardinality.get(col, 0) > high_thresh]

    print(f"One-hot encoding: {low_card}")
    print(f"Frequency encoding: {mid_card}")
    print(f"Target encoding: {high_card}")

    df = df.categorize(columns=low_card)

    # One-hot encoding
    df = dd.get_dummies(df, columns=low_card, dtype=int, sparse=True)

    # Frequency encoding
    for col in mid_card:
        freq = df[col].value_counts().compute()
        df[col + "_freq"] = df[col].map(freq, meta=(col + "_freq", "float64"))

        df = df.drop(columns=[col])

    # Target encoding
    for col in high_card:
        try:
            mean_map = df.groupby(col)[target].mean().compute()
            df[col + "_target"] = df[col].map(mean_map, meta=(col + "_target", "float64"))
            df = df.drop(columns=[col])
        except Exception as e:
            print(f"Skipping target encoding for {col} due to error: {e}")

        # Move Fraud_Label to the end
    cols = [col for col in df.columns if col != "Fraud_Label"] + ["Fraud_Label"]
    df = df[cols]


    return df

if __name__ == '__main__':
    df = preprocess_with_dask('gaussian_process_assignment_solution/data/synthetic_fraud_dataset_train.csv')
    df.compute().to_csv("processed_dask.csv", index=False)