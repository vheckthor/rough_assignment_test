
import torch
import gpytorch
from gpytorch.models import ApproximateGP
from gpytorch.variational import VariationalStrategy
from gpytorch.variational import CholeskyVariationalDistribution
from sklearn.cluster import KMeans




# GPR using approximate inference -- for scaling up to large data, based on (Titsias, 2009, AISTATS)
class GPRegressionModel_VariationalSparse(ApproximateGP):
    def __init__(self, inducing_points):
        number_of_inducing_points = inducing_points.size(0) # first dimension of the tensor (num rows)
        variational_distribution = CholeskyVariationalDistribution(number_of_inducing_points)
        variational_strategy = VariationalStrategy(
            self,
            inducing_points,
            variational_distribution,
            learn_inducing_locations=True
        )
        
        super(GPRegressionModel_VariationalSparse, self).__init__(variational_strategy)
        
        self.mean_module = gpytorch.means.ConstantMean()
        self.covar_module = gpytorch.kernels.ScaleKernel(gpytorch.kernels.RBFKernel())

        # parameters for *learnt* mean and variance scaling
        self.a = torch.nn.Parameter(torch.tensor(1.0)) # mean scaler
        self.b = torch.nn.Parameter(torch.tensor(0.0)) # bias
        self.c = torch.nn.Parameter(torch.tensor(torch.pi/8)) # variance scaler

    def forward(self, x):
        mean = self.mean_module(x)
        covar = self.covar_module(x)
        return gpytorch.distributions.MultivariateNormal(mean, covar)

    def predict_probability(self, x, likelihood):
        self.eval() # this line causes a warning which we can ignore
        with torch.no_grad(), gpytorch.settings.fast_pred_var():
            pred = likelihood(self(x)) 
            pred_mean = pred.mean
            pred_variance = pred.variance

        # preventing divisions by zero
        self.c.data = torch.clamp(self.c.data, min=1e-6, max=20.0)

        # MacKay's approximation with scaled mean and variance for probabilities
        numerator = pred_mean*self.a + self.b 
        denominator = torch.sqrt(1 + (torch.pi*pred_variance*self.c) / 8)
        prob = torch.sigmoid(numerator/denominator)
            
        return prob
