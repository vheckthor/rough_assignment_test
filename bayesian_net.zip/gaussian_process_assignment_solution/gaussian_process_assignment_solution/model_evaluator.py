
from __future__ import annotations

import math

from typing import Dict, Sequence

import numpy as np
from sklearn import calibration, metrics


class ModelEvaluator():
    """Evaluate Bayesian network predictions using multiple performance metrics."""

    verbose: bool = False
    inference_time: float | None = None

    def __init__(self) -> None:
        pass

    # ------------------------------------------------------------------------------------------------------------------
    # Calibration and probability handling
    # ------------------------------------------------------------------------------------------------------------------
    def expected_calibration_loss(self, true_labels: Sequence[int], predicted_probabilities: Sequence[float], n_bins: int | None = None) -> float:
        if n_bins is None:
            n_bins = math.ceil(math.log2(len(true_labels)) + 1)

        prob_true, prob_pred = calibration.calibration_curve(true_labels, predicted_probabilities, n_bins=n_bins, strategy="uniform")
        bin_counts, _ = np.histogram(predicted_probabilities, bins=n_bins, range=(0, 1))
        non_empty_bins = bin_counts > 0
        bin_weights = bin_counts[non_empty_bins] / np.sum(bin_counts[non_empty_bins])
        return float(np.sum(bin_weights * np.abs(prob_true - prob_pred)))


    # ------------------------------------------------------------------------------------------------------------------
    # Metrics
    # ------------------------------------------------------------------------------------------------------------------
    def compute_performance(
        self,
        true_labels: Sequence[int],
        hard_predictions: Sequence[int],
        probability_predictions: Sequence[float],
    ) -> Dict[str, float]:
        epsilon = 1e-5
        true_array = np.asarray(true_labels, dtype=float) + epsilon
        probability_array = np.asarray(probability_predictions, dtype=float) + epsilon

        print("Y_true=" + str(true_labels))
        print("Y_pred=" + str(list(hard_predictions)))
        print("Y_prob=" + str(list(probability_predictions)))

        balanced_accuracy = metrics.balanced_accuracy_score(true_labels, hard_predictions)
        f1 = metrics.f1_score(true_labels, hard_predictions)
        false_positive_rate, true_positive_rate, _ = metrics.roc_curve(true_labels, probability_predictions, pos_label=1)
        auc_score = metrics.auc(false_positive_rate, true_positive_rate)
        brier_score = metrics.brier_score_loss(true_labels, probability_predictions)
        kl_divergence = float(np.sum(true_array * np.log(true_array / probability_array)))
        calibration_loss = self.expected_calibration_loss(true_labels, probability_predictions)

        print("\nCOMPUTING performance on test data...")
        print(f"Balanced Accuracy={balanced_accuracy:.4f}")
        print(f"F1 Score={f1:.4f}")
        print(f"Area Under Curve={auc_score:.4f}")
        print(f"Brier Score={brier_score:.4f}")
        print(f"KL Divergence={kl_divergence:.4f}")
        print(f"Expected Calibration Loss={calibration_loss:.4f}")

        results = {
            "balance_accuracy": balanced_accuracy,
            "f1_score": f1,
            "area_under_curve": auc_score,
            "brier_score": brier_score,
            "kl_divergence": kl_divergence,
            "ec_loss": calibration_loss,
        }
        return results


