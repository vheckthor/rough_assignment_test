import pandas as pd


def panda_data_preprocessing(file_path: str, target: str = None, low_thresh: int = 10, high_thresh: int = 50) -> pd.DataFrame:
    data = pd.read_csv(file_path)
        # Conditionally drop columns if filename contains 'synthetic_fraud'
    if 'synthetic_fraud' in file_path:
        columns_to_drop = ['Transaction_ID', 'User_ID']
        data.drop(columns=[col for col in columns_to_drop if col in data.columns], inplace=True)
        print(f"Dropped columns: {columns_to_drop}")

    target = target if target else data.columns[-1]
    print(f"Target column: {target}")

    # Identify categorical columns
    categorical_cols = data.select_dtypes(include=["object", "category"]).columns.tolist()
    if target in categorical_cols:
        categorical_cols.remove(target)

    # Determine cardinality
    cardinality = {col: data[col].nunique() for col in categorical_cols}
    low_card_cols = [col for col in categorical_cols if cardinality[col] <= low_thresh]
    mid_card_cols = [col for col in categorical_cols if low_thresh < cardinality[col] <= high_thresh]
    high_card_cols = [col for col in categorical_cols if cardinality[col] > high_thresh]

    print(f"One-hot encoding: {low_card_cols}")
    print(f"Frequency encoding: {mid_card_cols}")
    print(f"Target encoding: {high_card_cols}")

    # One-hot encoding (sparse)
    data = pd.get_dummies(data, columns=low_card_cols, dtype=int, sparse=True)

    # Frequency encoding
    for col in mid_card_cols:
        freq_map = data[col].value_counts().to_dict()
        data[col + "_freq"] = data[col].map(freq_map)
        data.drop(columns=[col], inplace=True)

    # Target encoding
    for col in high_card_cols:
        target_mean = data.groupby(col)[target].mean().to_dict()
        data[col + "_target"] = data[col].map(target_mean)
        data.drop(columns=[col], inplace=True)
    
        # Move Fraud_Label to the end
    if 'synthetic_fraud' in file_path:
        cols = [col for col in data.columns if col != "Fraud_Label"] + ["Fraud_Label"]
        data = data[cols]

    return data