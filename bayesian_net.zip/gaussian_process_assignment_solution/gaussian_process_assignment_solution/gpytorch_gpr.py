##################################################
# gpytorch_gpr.py
# an adapted version of the gpytorch_gpr.py file from the aai-workshop-w5
##################################################

from __future__ import annotations

import sys
import time
from pathlib import Path
from typing import Tuple

import gpytorch
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
import torch
from gpytorch.kernels import RBFKernel, ScaleKernel
from sklearn.preprocessing import StandardScaler

from gpytorch_variational_sparse import GPRegressionModel_VariationalSparse
from gpytorch_gpr_util import EarlyStopping, GPRegressionModel
from model_evaluator import ModelEvaluator


class GaussianProcessClassifier:
    """Train and evaluate a Gaussian Process classifier using GPyTorch."""

    MAX_TRAIN_SAMPLES = 20_000
    LEARNING_RATE = 0.10
    MAX_EPOCHS = 1000
    GP_METHOD_2_EMPLOY='GPR'

    def __init__(
        self,
        train_csv_path: str | Path,
        test_csv_path: str | Path,
        kernel: ScaleKernel = ScaleKernel(RBFKernel()),
        use_mackay_approximation: bool = False,
        standardize_features: bool = True,
        enable_data_sampling: bool = False,
        gp_method_2_employ: str = 'GPR',
        cluster_count: int = 20
    ) -> None:
        self.kernel = kernel
        self.use_mackay_approximation = use_mackay_approximation
        self.standardize_features = standardize_features
        self.GP_METHOD_2_EMPLOY = gp_method_2_employ
        self.cluster_count = cluster_count

        train_features, train_targets = self._load_dataset(train_csv_path, enable_data_sampling)
        print(f"train_features: {train_features.shape}")
        print(f"train_targets: {train_targets.shape}")
        if len(train_features) // cluster_count < 2:
            print(f"Error: cluster_count {cluster_count} is too large for the training data")
            exit(0)
        test_features, test_targets = self._load_dataset(test_csv_path, enable_data_sampling)
        train_features, test_features = self._standardize_features(train_features, test_features)

        self.metrics: dict = {}
        print(f"{len(train_features)} training instances")
        print(f"{len(test_features)} test instances")

        device_type = "cuda" if torch.cuda.is_available() else "cpu"
        self.device = torch.device(device_type)
        print(f"Using device: {self.device}")

        train_features_tensor = torch.tensor(train_features, dtype=torch.float32).to(self.device)
        train_targets_tensor = torch.tensor(train_targets.values, dtype=torch.float32).to(self.device)
        test_features_tensor = torch.tensor(test_features, dtype=torch.float32)
        test_targets_tensor = torch.tensor(test_targets.values, dtype=torch.float32)

        model, likelihood, training_time = self._train_model(train_features_tensor, train_targets_tensor)
        _, _, self.metrics = self._evaluate_model(
            test_features_tensor,
            test_targets_tensor,
            model,
            likelihood,
            training_time,
        )

    def _load_dataset(
        self,
        csv_path: str | Path,
        enable_data_sampling: bool = False,
    ) -> Tuple[pd.DataFrame, pd.Series]:
        print("LOADING and PROCESSING data...")
        dataset = pd.read_csv(csv_path, encoding="latin")
        features = dataset.iloc[:, :-1]
        targets = dataset.iloc[:, -1]

        if enable_data_sampling and len(features) > self.MAX_TRAIN_SAMPLES:
            sampled_indices = np.random.choice(features.index, self.MAX_TRAIN_SAMPLES, replace=False)
            features = features.loc[sampled_indices]
            targets = targets.loc[sampled_indices]

        return features, targets

    def _standardize_features(
        self,
        train_features: pd.DataFrame,
        test_features: pd.DataFrame,
    ) -> Tuple[np.ndarray, np.ndarray]:
        print(f"STANDARDISE_DATA={self.standardize_features}")

        if self.standardize_features:
            scaler = StandardScaler()
            train_scaled = scaler.fit_transform(train_features)
            test_scaled = scaler.transform(test_features)
            return train_scaled, test_scaled

        return train_features.values, test_features.values

    @staticmethod
    def _compute_gaussian_density(value: float, mean: float, variance: float) -> float:
        exponent = -np.power((value - mean), 2) / (2 * variance)
        return (1 / (np.sqrt(2 * np.pi * variance))) * np.exp(exponent)

        # returns the predicted probabilities using the learnt factors for MacKay's approximation
    
    def get_predicted_probabilities(self, 
    train_features: torch.Tensor, 
    model: GPRegressionModel | GPRegressionModel_VariationalSparse, 
    likelihood: gpytorch.likelihoods.GaussianLikelihood):
        if self.GP_METHOD_2_EMPLOY == 'GPR_VarSparse':
            probs = model.predict_probability(train_features, likelihood)
        else:
            probs = model.predict_probability(train_features)
        return probs
    
    
    def _train_model(self, train_features: torch.Tensor, train_targets: torch.Tensor):
        print("\nTRAINING Gaussian Process model...")
        print(f"use_mackay_approximation={self.use_mackay_approximation}")
        training_start = time.time()

        likelihood = gpytorch.likelihoods.GaussianLikelihood().to(self.device)
        early_stopper = EarlyStopping()        
        
        # the model is created based on the type of GP selected in GP_METHOD_2_EMPLOY
        if self.GP_METHOD_2_EMPLOY == 'GPR' or self.GP_METHOD_2_EMPLOY == 'GPR_Sparse':        
            model = GPRegressionModel(train_features, 
            train_targets, 
            likelihood, 
            self.GP_METHOD_2_EMPLOY, 
            self.cluster_count, 
            self.kernel).to(self.device)

            # optimiser for the GP model via the MLL loss function
            print("Loss function: Marginal Log Likelihood (MLL)")
            optimiser1 = torch.optim.Adam(model.parameters(), lr=self.LEARNING_RATE)  
            marginal_log_likelihood = gpytorch.mlls.ExactMarginalLogLikelihood(likelihood, model)


        if self.GP_METHOD_2_EMPLOY == 'GPR_VarSparse': 
            kmeans = KMeans(
                n_clusters=self.cluster_count, 
                init='k-means++', 
                random_state=0).fit(train_features.cpu().numpy())
            inducing_points = torch.tensor(
                kmeans.cluster_centers_, 
                dtype=torch.float).to(train_features.device)
            model = GPRegressionModel_VariationalSparse(inducing_points).to(self.device)

            # optimiser for the GP model via the MLL loss function
            # note that the likelihood is included in the optimiser because is not part of the model as in 'GPR'
            print("Loss function: Evidence Lower Bound (ELBO)")
            parameters = [{'params': model.parameters()}, {'params': likelihood.parameters()}]
            optimiser1 = torch.optim.Adam(parameters, lr=self.LEARNING_RATE/2) # smaller lr than Exact GP
            marginal_log_likelihood = gpytorch.mlls.VariationalELBO(likelihood, model, num_data=train_features.size(0))

        model.train()
        likelihood.train()

        print("Loss function: Marginal Log Likelihood (MLL)")
        optimiser = torch.optim.Adam(model.parameters(), lr=self.LEARNING_RATE)
        marginal_log_likelihood = gpytorch.mlls.ExactMarginalLogLikelihood(likelihood, model)

        # for epoch in range(self.MAX_EPOCHS):
        #     optimiser.zero_grad()
        #     predictions = model(train_features)
        #     loss = -marginal_log_likelihood(predictions, train_targets)
        #     loss.backward()
        #     optimiser.step()
        #     if early_stopper.check_early_stopping(epoch, loss.item()):
        #         break
        for i in range(self.MAX_EPOCHS):
            optimiser1.zero_grad()
            output = model(train_features)
            loss = -marginal_log_likelihood(output, train_targets)
            loss.backward()
            optimiser1.step()
            if early_stopper.check_early_stopping(i, loss.item()):
                break



        # print("\nGaussian Process learnt parameters (after optimisation):")
        # print(f"Lengthscale={model.covar_module.base_kernel.lengthscale.item()}")
        # print(f"Outputscale={model.covar_module.outputscale.item()}")
        # print(f"Noise={model.likelihood.noise.item()}")

        if self.use_mackay_approximation:
            for parameter in model.mean_module.parameters():
                parameter.requires_grad = False
            for parameter in model.covar_module.parameters():
                parameter.requires_grad = False

            print("\nLoss function: Binary Cross Entropy (BCE)")
            optimiser_mackay = torch.optim.Adam([model.a, model.b, model.c], lr=self.LEARNING_RATE)
            bce_loss = torch.nn.BCELoss()
            early_stopper.reset()

            for epoch in range(self.MAX_EPOCHS):
                optimiser_mackay.zero_grad()
                probabilities = self.get_predicted_probabilities(train_features, model, likelihood)
                loss = bce_loss(probabilities, train_targets)
                loss.backward()
                optimiser_mackay.step()
                if early_stopper.check_early_stopping(epoch, loss.item()):
                    break

            print(f"Scaling factors a={model.a.item()}, b={model.b.item()}, c={model.c.item()}")

        training_time = time.time() - training_start
        return model, likelihood, training_time

    def _evaluate_model(
        self,
        test_features: torch.Tensor,
        test_targets: torch.Tensor,
        model: GPRegressionModel | GPRegressionModel_VariationalSparse,
        likelihood: gpytorch.likelihoods.GaussianLikelihood,
        training_time: float,
    ):
        print("\nEVALUATING Gaussian Process model...")
        print(f"use_mackay_approximation={self.use_mackay_approximation}")

        evaluation_start = time.time()
        model.eval()
        likelihood.eval()

        true_labels = test_targets.numpy().tolist()
        predicted_labels: list[float] = []
        predicted_probabilities: list[float] = []

        for row in test_features:
            feature_tensor = torch.tensor(np.array([row]), dtype=torch.float32).to(self.device)

            if self.use_mackay_approximation:
                probability = self.get_predicted_probabilities(feature_tensor, model, likelihood) 
                probability = probability.cpu().item() # numpy value
            else:
                with torch.no_grad(), gpytorch.settings.fast_pred_var():
                    predictions = likelihood(model(feature_tensor))
                    mean_value = predictions.mean.item()
                    variance_value = predictions.variance.item()
                    density_one = self._compute_gaussian_density(1, mean_value, variance_value)
                    density_zero = self._compute_gaussian_density(0, mean_value, variance_value)
                    probability = density_one / (density_one + density_zero)

            predicted_probabilities.append(probability)
            predicted_labels.append(float(np.round(probability)))

        inference_time = time.time() - evaluation_start
        evaluator = ModelEvaluator()
        evaluator.inference_time = inference_time
        performance = evaluator.compute_performance(true_labels, predicted_labels, predicted_probabilities)

        print(f"Training Time={training_time:.4f} secs.")
        print(f"Test Time={inference_time:.4f} secs.")

        performance["training_time"] = training_time
        performance["test_time"] = inference_time
        return model, likelihood, performance


GPR = GaussianProcessClassifier


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("USAGE: gpytorch_gpr.py [train_file.csv] [test_file.csv]")
        print(
            "EXAMPLE> gpytorch_gpr.py data_banknote_authentication-train.csv data_banknote_authentication-test.csv"
        )
        sys.exit(0)

    train_file = sys.argv[1]
    test_file = sys.argv[2]
    GaussianProcessClassifier(train_file, test_file)
