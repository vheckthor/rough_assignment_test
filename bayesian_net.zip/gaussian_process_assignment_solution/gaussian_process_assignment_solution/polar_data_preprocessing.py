import polars as pl

def preprocess_with_polars(file_path: str, target: str = None, low_thresh: int = 10, high_thresh: int = 50) -> pl.DataFrame:
    df = pl.read_csv(file_path)
    target = target or df.columns[-1]
    print(f"Target column: {target}")

    # Identify categorical columns
    categorical_cols = [col for col in df.columns if df[col].dtype in [pl.Utf8, pl.Categorical] and col != target]

    # Cardinality
    cardinality = {col: df[col].n_unique() for col in categorical_cols}
    low_card = [col for col in categorical_cols if cardinality[col] <= low_thresh]
    mid_card = [col for col in categorical_cols if low_thresh < cardinality[col] <= high_thresh]
    high_card = [col for col in categorical_cols if cardinality[col] > high_thresh]

    print(f"One-hot encoding: {low_card}")
    print(f"Frequency encoding: {mid_card}")
    print(f"Target encoding: {high_card}")

    # One-hot encoding
    for col in low_card:
        df = df.to_dummies(columns=[col])

    # Frequency encoding
    for col in mid_card:
        freq = df.group_by(col).agg(pl.count()).rename({col: f"{col}_freq"})
        df = df.join(freq, on=col).drop(col)

    # Target encoding
    for col in high_card:
        target_mean = df.group_by(col).agg(pl.mean(target)).rename({target: f"{col}_target"})
        df = df.join(target_mean, on=col).drop(col)
    
    # Move Fraud_Label to the end
    cols = [col for col in df.columns if col != "Fraud_Label"] + ["Fraud_Label"]
    df = df[cols]

    return df

if __name__ == '__main__':
    value = preprocess_with_polars('gaussian_process_assignment_solution/data/synthetic_fraud_dataset_train.csv')
    value.write_csv("processed_polars.csv")