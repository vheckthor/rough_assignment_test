from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
from sklearn.model_selection import train_test_split
from gpytorch.kernels import MaternKernel, RBFKernel, RQKernel, ScaleKernel

from panda_data_preprocessing import panda_data_preprocessing
from gpytorch_gpr import GPR


def update_score_table(score_dict: dict, kernel: str, mackay: bool, df: pd.DataFrame, standardized: bool, gp_method: str, cluster_count: int = None) -> pd.DataFrame:
    """
    Updates or creates a DataFrame with scores for a given kernel and Mackay value.

    Parameters:
        score_dict (dict): e.g., {'brier_score': 0.2, 'f1_score': 2.5}
        kernel (str): e.g., 'RBFKernel'
        mackay (bool): True or False
        df (pd.DataFrame or None): existing DataFrame to update, or None to create a new one

    Returns:
        pd.DataFrame: updated DataFrame with new scores inserted
    """
    cluster_count_str = "K" + str(cluster_count) if cluster_count else ''
    col_name = f"{gp_method}_{cluster_count_str}_{kernel}_MACKAY_{str(mackay).upper()}_STANDARDIZED_{str(standardized).upper()}"

    # Create new DataFrame if none exists
    if df is None:
        df = pd.DataFrame(index=score_dict.keys())

    # Ensure the column exists
    if col_name not in df.columns:
        df[col_name] = pd.NA

    # Insert the values
    for score, value in score_dict.items():
        if score not in df.index:
            df.loc[score] = pd.NA
        df.at[score, col_name] = value

    return df


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Split a CSV file into training and test sets.")
    parser.add_argument("csv_path", type=str, help="Path to the input CSV file")
    parser.add_argument(
        "train_ratio",
        type=float,
        help="Training set ratio (e.g., 0.8 for 80% training)",
    )
    return parser.parse_args()


def get_preprocessed_dataframe(csv_path: Path, preprocessed_path: Path) -> pd.DataFrame:
    if preprocessed_path.exists():
        return pd.read_csv(preprocessed_path)

    df = panda_data_preprocessing(str(csv_path))
    df.to_csv(preprocessed_path, index=False)
    return df


def prepare_datasets(
    df: pd.DataFrame,
    training_ratio: float,
    base_name: str,
    output_dir: Path,
) -> tuple[Path, Path, bool]:
    train_df, test_df = train_test_split(df, train_size=training_ratio, random_state=42)

    train_path = output_dir / f"{base_name}_train.csv"
    test_path = output_dir / f"{base_name}_test.csv"

    train_df.to_csv(train_path, index=False)
    test_df.to_csv(test_path, index=False)

    print(f"✅ Split complete:\n- Training set: {train_path}\n- Test set: {test_path}")

    use_data_sampling = len(train_df) > 25_000 or len(test_df) > 25_000
    return train_path, test_path, use_data_sampling


def run_experiments(
    train_path: Path,
    test_path: Path,
    result_filepath: Path,
    use_data_sampling: bool = True,
) -> None:
    kernels = [
        ScaleKernel(RBFKernel()),
        ScaleKernel(MaternKernel(nu=0.5)),
        ScaleKernel(MaternKernel(nu=1.5)),
        ScaleKernel(MaternKernel(nu=2.5)),
        ScaleKernel(RQKernel(alpha=1.0)),
    ]
    gp_methods = [
         'GPR',
         'GPR_Sparse',
        'GPR_VarSparse',
    ]
    cluster_counts = [10, 20, 100, 200, 300]
    use_mackay_approximation = [True, False]
    standardize_data = [True, False]

    result_data_gpr = pd.DataFrame()
    result_sparse_gpr = pd.DataFrame()
    result_var_sparse_gpr = pd.DataFrame()
    for gp_method in gp_methods:
        if gp_method == 'GPR':
            print("===============Starting Model Training===========")
            for kernel in kernels:
                for mackay in use_mackay_approximation:
                    for standardized in standardize_data:
                        kernel_name = kernel.base_kernel._get_name()
                        gpr = GPR(
                            str(train_path),
                            str(test_path),
                            kernel,
                            mackay,
                            standardized,
                            use_data_sampling,
                            gp_method,
                        )
                        result_data_gpr = update_score_table(gpr.metrics, kernel_name, mackay, result_data_gpr, standardized, gp_method)
        else:
            for cluster_count in cluster_counts:
                for kernel in kernels:
                    for mackay in use_mackay_approximation:
                        for standardized in standardize_data:
                            kernel_name = kernel.base_kernel._get_name()
                            gpr = GPR(
                                str(train_path),
                                str(test_path),
                                kernel,
                                mackay,
                                standardized,
                                False,
                                gp_method,
                                cluster_count,
                            )
                            if gp_method == 'GPR_Sparse':
                                result_sparse_gpr = update_score_table(gpr.metrics, kernel_name, mackay, result_sparse_gpr, standardized, gp_method, cluster_count)
                            elif gp_method == 'GPR_VarSparse':
                                result_var_sparse_gpr = update_score_table(gpr.metrics, kernel_name, mackay, result_var_sparse_gpr, standardized, gp_method, cluster_count) 

    result_data_gpr.to_csv(str(result_filepath).replace('.csv', '_gpr.csv'))
    result_sparse_gpr.to_csv(str(result_filepath).replace('.csv', '_sparse_gpr.csv'))
    result_var_sparse_gpr.to_csv(str(result_filepath).replace('.csv', '_var_sparse_gpr.csv'))


def main() -> None:
    args = parse_arguments()

    csv_path = Path(args.csv_path).expanduser()
    if not csv_path.exists():
        raise FileNotFoundError(f"CSV file '{csv_path}' does not exist.")

    training_ratio = args.train_ratio
    dir_path = csv_path.parent
    base_name = csv_path.stem

    preprocessed_path = dir_path / f"{base_name}_preprocessed.csv"
    df = get_preprocessed_dataframe(csv_path, preprocessed_path)

    results_dir = Path("results")
    results_dir.mkdir(parents=True, exist_ok=True)
    result_filepath = results_dir / f"{base_name}_result.csv"

    if result_filepath.exists():
        print(f"🗑️ Deleted existing file: {result_filepath}")
        result_filepath.unlink()

    train_path, test_path, use_data_sampling = prepare_datasets(
        df,
        training_ratio,
        base_name,
        dir_path,
    )
    run_experiments(train_path, test_path, result_filepath, use_data_sampling)


if __name__ == '__main__':
    main()