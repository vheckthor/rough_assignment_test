"""Command-line tool for probabilistic inference with the gpytorch GPR pipeline.

This script trains a Gaussian Process classifier on a CSV dataset and produces
probability estimates for another CSV (often a held-out test split).  It reuses
the project utilities (GPRegressionModel, EarlyStopping) to remain consistent
with the existing training code, while exposing a convenient interface for
generating per-sample probabilities and optional evaluation metrics.

Expected data format:
    * CSV files with the target column positioned last by default (override via
      ``--target-column``).
    * Binary labels encoded as {0, 1} or {False, True}.
    * Numeric features (preprocess categorical columns beforehand, e.g. via
      ``panda_data_preprocessing.py``).

Example usage:
    python run_probabilistic_inference.py \
        --train data/synthetic_fraud_dataset_train.csv \
        --predict data/synthetic_fraud_dataset_test.csv \
        --kernel rbf --mackay --output results/probabilities.csv

The script prints metrics (when ground-truth labels are available), shows a
preview of the inferred probabilities, and optionally saves detailed outputs to
CSV/JSON files.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, Iterable, Optional, Tuple

import gpytorch
import numpy as np
import pandas as pd
import torch
from gpytorch.kernels import MaternKernel, RBFKernel, RQKernel, ScaleKernel
from sklearn import metrics
from sklearn.calibration import calibration_curve
from sklearn.preprocessing import StandardScaler

from gpytorch_gpr_util import EarlyStopping, GPRegressionModel


def _parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Train a GPyTorch Gaussian Process classifier and perform probabilistic inference.",
    )
    parser.add_argument("--train", required=True, help="CSV file used for training (target column required).")
    parser.add_argument(
        "--predict",
        help="CSV file used for inference. Defaults to --test when omitted.",
    )
    parser.add_argument(
        "--test",
        help="Optional CSV with ground-truth labels for evaluation (also used for inference if --predict is absent).",
    )
    parser.add_argument(
        "--target-column",
        help="Name of the target column. Defaults to the last column in the training CSV.",
    )
    parser.add_argument(
        "--kernel",
        choices=["rbf", "matern12", "matern32", "matern52", "rq"],
        default="rbf",
        help="Kernel choice for the GP model (default: rbf).",
    )
    parser.add_argument(
        "--mackay",
        action="store_true",
        help="Enable MacKay's sigmoid approximation with learnable scaling factors.",
    )
    parser.add_argument(
        "--query",
        action="append",
        help="Probabilistic query in the form P(Target|Feature1=value,Feature2=value). Can be repeated.",
    )
    parser.add_argument(
        "--query-fill",
        choices=["mean", "median", "zero"],
        default="mean",
        help="Strategy to fill unspecified features in --query expressions (default: mean).",
    )
    parser.add_argument(
        "--no-standardize",
        action="store_true",
        help="Disable feature standardisation (enabled by default).",
    )
    parser.add_argument("--learning-rate", type=float, default=0.10, help="Learning rate for optimisers (default: 0.10).")
    parser.add_argument(
        "--max-epochs",
        type=int,
        default=1000,
        help="Maximum training epochs for each optimisation stage (default: 1000).",
    )
    parser.add_argument(
        "--output",
        help="Path to save per-sample probabilities as CSV.",
    )
    parser.add_argument(
        "--metrics-json",
        help="Optional path to dump evaluation metrics as JSON (only when ground truth is available).",
    )
    parser.add_argument("--seed", type=int, default=42, help="Random seed for reproducibility.")
    return parser.parse_args()


def _set_random_seed(seed: int) -> None:
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _resolve_kernel(name: str) -> ScaleKernel:
    base_kernel = {
        "rbf": RBFKernel(),
        "matern12": MaternKernel(nu=0.5),
        "matern32": MaternKernel(nu=1.5),
        "matern52": MaternKernel(nu=2.5),
        "rq": RQKernel(alpha=1.0),
    }[name]
    return ScaleKernel(base_kernel)


def _load_dataframe(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"File '{path}' does not exist.")
    return pd.read_csv(path)


def _split_features_target(
    df: pd.DataFrame,
    target_column: Optional[str],
    require_target: bool,
) -> Tuple[pd.DataFrame, Optional[pd.Series]]:
    column = target_column or df.columns[-1]
    if column not in df.columns:
        if require_target:
            raise ValueError(f"Target column '{column}' not found in dataframe.")
        return df.copy(), None

    features = df.drop(columns=[column])
    target = df[column].astype(float)
    return features, target


def _standardise_features(
    X_train: pd.DataFrame,
    X_other: Optional[pd.DataFrame],
    enabled: bool,
) -> Tuple[np.ndarray, Optional[np.ndarray], Optional[StandardScaler]]:
    if not enabled:
        return X_train.to_numpy(dtype=np.float32), None if X_other is None else X_other.to_numpy(dtype=np.float32), None

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_other_scaled = scaler.transform(X_other) if X_other is not None else None
    return X_train_scaled.astype(np.float32), None if X_other_scaled is None else X_other_scaled.astype(np.float32), scaler


def _coerce_evidence_value(raw_value: str) -> float:
    value = raw_value.strip()
    if value.lower() in {"true", "yes"}:
        return 1.0
    if value.lower() in {"false", "no"}:
        return 0.0
    try:
        return float(value)
    except ValueError as exc:
        raise ValueError(f"Evidence value '{raw_value}' is not numeric; please preprocess your features first.") from exc


def _parse_probabilistic_query(prob_query: str) -> Tuple[str, Dict[str, float]]:
    text = prob_query.strip()
    if not (text.startswith("P(") and text.endswith(")")):
        raise ValueError(f"Query '{prob_query}' must follow the pattern P(Target|Feature=value,...).")

    inner = text[2:-1].strip()
    if "|" in inner:
        lhs, rhs = inner.split("|", 1)
        evidence_text = rhs.strip()
    else:
        lhs = inner
        evidence_text = ""

    target = lhs.strip()
    evidence: Dict[str, float] = {}

    if evidence_text:
        for pair in evidence_text.split(","):
            pair = pair.strip()
            if not pair:
                continue
            if "=" not in pair:
                raise ValueError(f"Evidence token '{pair}' in query '{prob_query}' is missing '='.")
            key, value = pair.split("=", 1)
            key = key.strip()
            if not key:
                raise ValueError(f"Evidence token '{pair}' has an empty feature name.")
            evidence[key] = _coerce_evidence_value(value)

    return target, evidence


def _build_query_dataset(
    queries: Iterable[str],
    feature_columns: Iterable[str],
    target_column: str,
) -> Tuple[pd.DataFrame, pd.Series, list, list]:
    rows = []
    annotations = []
    missing_features: list[list[str]] = []

    feature_list = list(feature_columns)

    for query in queries:
        query_target, evidence = _parse_probabilistic_query(query)
        if query_target != target_column:
            raise ValueError(
                f"Query '{query}' targets '{query_target}', but the model was trained for '{target_column}'."
            )

        ordered_row = []
        missing = []
        for column in feature_list:
            if column in evidence:
                ordered_row.append(evidence[column])
            else:
                ordered_row.append(np.nan)
                missing.append(column)

        rows.append(ordered_row)
        annotations.append({"source": "query", "query_expression": query, "filled_features": ""})
        missing_features.append(missing)

    df = pd.DataFrame(rows, columns=feature_list)
    labels = pd.Series([np.nan] * len(rows), name=target_column, dtype=float)
    return df, labels, annotations, missing_features


def _default_feature_values(df: pd.DataFrame, strategy: str) -> pd.Series:
    if strategy == "mean":
        values = df.mean()
    elif strategy == "median":
        values = df.median()
    elif strategy == "zero":
        values = pd.Series(0.0, index=df.columns, dtype=float)
    else:
        raise ValueError(f"Unsupported query fill strategy '{strategy}'.")

    values = values.reindex(df.columns, fill_value=0.0)
    values = values.astype(float).fillna(0.0)
    return values


def _train_gaussian_process(
    X_train: np.ndarray,
    y_train: np.ndarray,
    kernel: ScaleKernel,
    use_mackay: bool,
    learning_rate: float,
    max_epochs: int,
    device: torch.device,
) -> Tuple[GPRegressionModel, gpytorch.likelihoods.GaussianLikelihood, float]:
    train_x = torch.tensor(X_train, dtype=torch.float32, device=device)
    train_y = torch.tensor(y_train, dtype=torch.float32, device=device)

    likelihood = gpytorch.likelihoods.GaussianLikelihood().to(device)
    model = GPRegressionModel(train_x, train_y, likelihood, kernel).to(device)
    early_stopping = EarlyStopping()

    model.train()
    likelihood.train()

    optimiser = torch.optim.Adam(model.parameters(), lr=learning_rate)
    mll = gpytorch.mlls.ExactMarginalLogLikelihood(likelihood, model)

    start_time = torch.cuda.Event(enable_timing=True) if device.type == "cuda" else None
    end_time = torch.cuda.Event(enable_timing=True) if device.type == "cuda" else None
    if start_time is not None:
        start_time.record()

    for epoch in range(max_epochs):
        optimiser.zero_grad()
        output = model(train_x)
        loss = -mll(output, train_y)
        loss.backward()
        optimiser.step()
        if early_stopping.check_early_stopping(epoch, loss.item()):
            break

    # Optional second phase: MacKay approximation parameters (a, b, c)
    if use_mackay:
        for params in model.mean_module.parameters():
            params.requires_grad = False
        for params in model.covar_module.parameters():
            params.requires_grad = False

        optimiser2 = torch.optim.Adam([model.a, model.b, model.c], learning_rate)
        bce = torch.nn.BCELoss()
        early_stopping.reset()

        for epoch in range(max_epochs):
            optimiser2.zero_grad()
            probs = model.predict_probability(train_x)
            loss = bce(probs, train_y)
            loss.backward()
            optimiser2.step()
            if early_stopping.check_early_stopping(epoch, loss.item()):
                break

    if start_time is not None and end_time is not None:
        end_time.record()
        torch.cuda.synchronize()
        training_time = start_time.elapsed_time(end_time) / 1000.0
    else:
        training_time = 0.0

    return model, likelihood, training_time


def _gaussian_pdf(x: float, mean: np.ndarray, var: np.ndarray) -> np.ndarray:
    var = np.clip(var, a_min=1e-9, a_max=None)
    numerator = np.exp(-0.5 * ((x - mean) ** 2) / var)
    denominator = np.sqrt(2 * np.pi * var)
    return numerator / denominator


def _predict_probabilities(
    model: GPRegressionModel,
    likelihood: gpytorch.likelihoods.GaussianLikelihood,
    X: np.ndarray,
    use_mackay: bool,
    device: torch.device,
) -> np.ndarray:
    model.eval()
    likelihood.eval()
    test_x = torch.tensor(X, dtype=torch.float32, device=device)

    if use_mackay:
        with torch.no_grad():
            probs = model.predict_probability(test_x).cpu().numpy()
        return probs

    with torch.no_grad(), gpytorch.settings.fast_pred_var():
        posterior = likelihood(model(test_x))
        mean = posterior.mean.cpu().numpy()
        var = posterior.variance.cpu().numpy()

    pdf_pos = _gaussian_pdf(1.0, mean, var)
    pdf_neg = _gaussian_pdf(0.0, mean, var)
    denominator = np.clip(pdf_pos + pdf_neg, a_min=1e-12, a_max=None)
    return pdf_pos / denominator


def _expected_calibration_loss(y_true: np.ndarray, y_prob: np.ndarray) -> float:
    y_true = np.asarray(y_true)
    y_prob = np.asarray(y_prob)
    if len(y_true) == 0:
        return float("nan")

    n_bins = int(np.ceil(np.log2(len(y_true)) + 1))
    prob_true, prob_pred = calibration_curve(y_true, y_prob, n_bins=n_bins, strategy="uniform")
    bin_counts, _ = np.histogram(y_prob, bins=n_bins, range=(0, 1))
    nonempty = bin_counts > 0
    if not np.any(nonempty):
        return float("nan")
    weights = bin_counts[nonempty] / np.sum(bin_counts[nonempty])
    return float(np.sum(weights * np.abs(prob_true - prob_pred)))


def _compute_metrics(y_true: np.ndarray, y_prob: np.ndarray) -> Dict[str, float]:
    y_true = np.asarray(y_true)
    y_prob = np.asarray(y_prob)
    y_pred = np.round(y_prob)

    results: Dict[str, float] = {}
    results["balanced_accuracy"] = metrics.balanced_accuracy_score(y_true, y_pred)
    results["f1_score"] = metrics.f1_score(y_true, y_pred)
    fpr, tpr, _ = metrics.roc_curve(y_true, y_prob, pos_label=1)
    results["area_under_curve"] = metrics.auc(fpr, tpr)
    results["brier_score"] = metrics.brier_score_loss(y_true, y_prob)

    epsilon = 1e-5
    P = y_true + epsilon
    Q = y_prob + epsilon
    results["kl_divergence"] = float(np.sum(P * np.log(P / Q)))
    results["expected_calibration_loss"] = _expected_calibration_loss(y_true, y_prob)
    return results


def _preview_dataframe(df: pd.DataFrame, max_rows: int = 5) -> str:
    with pd.option_context("display.max_columns", None, "display.width", 120):
        return df.head(max_rows).to_string(index=False)


def main() -> None:
    args = _parse_arguments()
    _set_random_seed(args.seed)

    train_path = Path(args.train)
    predict_path = Path(args.predict) if args.predict else None
    test_path = Path(args.test) if args.test else None

    if not args.query and predict_path is None:
        if test_path is None:
            raise ValueError("Provide --predict/--test or --query to specify inference data.")
        predict_path = test_path

    train_df = _load_dataframe(train_path)

    target_column_arg = args.target_column
    X_train_df, y_train_series = _split_features_target(train_df, target_column_arg, require_target=True)

    inferred_target = y_train_series.name or train_df.columns[-1]
    target_column = target_column_arg or inferred_target

    predict_feature_frames = []
    label_series_list = []
    row_annotations = []

    if predict_path is not None:
        predict_df = _load_dataframe(predict_path)
        X_predict_df, y_predict_series = _split_features_target(predict_df, target_column, require_target=False)
        if y_predict_series is None and test_path is not None and test_path == predict_path:
            # Attempt to recover labels from the test CSV when predict==test.
            _, y_predict_series = _split_features_target(predict_df, target_column, require_target=True)

        predict_feature_frames.append(X_predict_df.reset_index(drop=True))
        if y_predict_series is not None:
            label_series_list.append(y_predict_series.reset_index(drop=True).astype(float))
        else:
            label_series_list.append(pd.Series([np.nan] * len(X_predict_df), name=target_column, dtype=float))
        row_annotations.extend([
            {"source": "file", "origin": str(predict_path), "filled_features": ""}
            for _ in range(len(X_predict_df))
        ])

    if args.query:
        default_values = _default_feature_values(X_train_df, args.query_fill)
        query_df, query_labels, query_annotations, query_missing = _build_query_dataset(
            args.query, X_train_df.columns, target_column
        )
        fill_logs = []
        for idx, missing_cols in enumerate(query_missing):
            if missing_cols:
                for column in missing_cols:
                    query_df.iat[idx, query_df.columns.get_loc(column)] = default_values[column]
                query_annotations[idx]["filled_features"] = ",".join(missing_cols)
                fill_logs.append(
                    f"Query '{query_annotations[idx]['query_expression']}' missing {missing_cols}; filled using {args.query_fill}."
                )
        if fill_logs:
            print("\nFilled missing features for --query entries:")
            for log in fill_logs:
                print(f" - {log}")

        predict_feature_frames.append(query_df.reset_index(drop=True))
        label_series_list.append(query_labels.reset_index(drop=True))
        row_annotations.extend(query_annotations)

    if not predict_feature_frames:
        raise ValueError("No inference data provided; supply --query or a CSV via --predict/--test.")

    X_predict_df = pd.concat(predict_feature_frames, ignore_index=True)
    combined_labels = pd.concat(label_series_list, ignore_index=True)
    y_predict_series = None if combined_labels.isna().all() else combined_labels

    standardise = not args.no_standardize
    X_train_np, X_predict_np, scaler = _standardise_features(X_train_df, X_predict_df, standardise)

    y_train_np = y_train_series.to_numpy(dtype=np.float32)
    y_predict_np = None if y_predict_series is None else y_predict_series.to_numpy(dtype=np.float32)

    kernel = _resolve_kernel(args.kernel)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model, likelihood, training_time = _train_gaussian_process(
        X_train_np,
        y_train_np,
        kernel,
        args.mackay,
        args.learning_rate,
        args.max_epochs,
        device,
    )

    probabilities = _predict_probabilities(model, likelihood, X_predict_np, args.mackay, device)
    predictions = np.round(probabilities).astype(int)

    output_df = X_predict_df.copy()
    output_df["prob_positive"] = probabilities
    output_df["predicted_label"] = predictions
    if y_predict_series is not None:
        output_df["true_label"] = y_predict_series.values
    else:
        output_df["true_label"] = np.nan

    if row_annotations:
        annotation_df = pd.DataFrame(row_annotations)
        output_df = pd.concat([annotation_df.reset_index(drop=True), output_df.reset_index(drop=True)], axis=1)

    print("\n=== Probabilistic Inference Preview ===")
    print(_preview_dataframe(output_df))

    if y_predict_series is not None:
        mask = ~np.isnan(y_predict_np)
        if mask.any():
            metrics_dict = _compute_metrics(y_predict_np[mask], probabilities[mask])
            metrics_dict["training_time_secs"] = training_time
            print("\n=== Evaluation Metrics ===")
            for key, value in metrics_dict.items():
                print(f"{key}: {value:.4f}")
            if args.metrics_json:
                metrics_path = Path(args.metrics_json)
                metrics_path.parent.mkdir(parents=True, exist_ok=True)
                with metrics_path.open("w", encoding="utf-8") as fp:
                    json.dump(metrics_dict, fp, indent=2)
        else:
            print("\n(Ground-truth labels not supplied; metrics skipped.)")
    else:
        print("\n(No ground-truth labels detected; metrics skipped.)")

    if args.output:
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_df.to_csv(output_path, index=False)
        print(f"\nSaved probabilities to {output_path}")


if __name__ == "__main__":
    main()


